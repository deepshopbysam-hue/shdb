import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  updateDoc,
} from "firebase/firestore";
import { db } from "../../firebase";
import { uploadToImgbb } from "../../services/imgbb";
import { useNotify, useConfirm } from "../../components/Notifications";
import { Product } from "../../types";
import { motion, AnimatePresence } from "framer-motion";
import Icon from "../../components/Icon";
import { Pen, Trash2, Box, Store, Sparkles, Cpu, Battery, Camera, Smartphone, Layers } from "lucide-react";
import { generatePartSvg, detectPhonePart } from "../../src/lib/phonePartsArt";

import { Button as UIButton } from "@/components/ui/button";
import { Item, ItemContent, ItemDescription, ItemGroup, ItemMedia, ItemTitle, ItemActions } from "../../components/ui/item";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";

import Modal from "../../components/ui/modal-drop";

const ManageProducts: React.FC = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const notify = useNotify();
  const confirm = useConfirm();

  const [formData, setFormData] = useState({
    name: "",
    price: 0,
    resellerPrice: 0,
    description: "",
    category: "Mobile",
    customCategory: "",
    stock: 10,
    imageFiles: [] as File[],
    isOffer: false,
    offerPrice: 0,
    productType: "normal" as "normal" | "offer" | "bypass" | "custom",
    advanceAmount: 0,
    modelUrl: "",
    videoUrl: "",
  });

  const fetchProducts = async () => {
    const snap = await getDocs(collection(db, "products"));
    setProducts(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Product));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleEdit = (product: Product) => {
    setEditingId(product.id);
    const prodType = product.productType || (product.isBypass ? "bypass" : product.isOffer ? "offer" : product.advanceType === "custom" ? "custom" : "normal");
    setFormData({
      name: product.name || "",
      price: product.price || 0,
      resellerPrice: product.resellerPrice || 0,
      description: product.description || "",
      category: product.category || "Mobile",
      customCategory: "",
      stock: product.stock || 0,
      imageFiles: [],
      isOffer: product.isOffer || prodType === "offer",
      offerPrice: product.offerPrice || 0,
      productType: prodType,
      advanceAmount: product.advanceAmount || 0,
      modelUrl: product.modelUrl || "",
      videoUrl: product.videoUrl || "",
    });
    setIsAdding(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      let imageUrls: string[] = [];
      if (formData.imageFiles.length > 0) {
        for (const file of formData.imageFiles) {
          const url = await uploadToImgbb(file);
          imageUrls.push(url);
        }
      }

      const isBypass = formData.productType === "bypass";
      const isOffer = Boolean(formData.isOffer || formData.productType === "offer");
      let calcAdvance = 0;
      if (formData.productType === "offer" || isOffer) {
        calcAdvance = Number(formData.isOffer && formData.offerPrice ? formData.offerPrice : formData.price || 0);
      } else if (formData.productType === "bypass") {
        calcAdvance = 0;
      } else if (formData.productType === "normal") {
        calcAdvance = Math.round(Number(formData.price || 0) * 0.5);
      } else {
        calcAdvance = Number(formData.advanceAmount || 0);
      }

      const productData: any = {
        name: formData.name,
        price: Number(formData.price),
        resellerPrice: Number(formData.resellerPrice || 0),
        description: formData.description,
        category: formData.category === "Custom" ? formData.customCategory : formData.category,
        stock: Number(formData.stock),
        isOffer: isOffer,
        isBypass: isBypass,
        productType: formData.productType,
        advanceType: formData.productType,
        advanceAmount: calcAdvance,
        offerPrice: Number(formData.offerPrice || 0),
        modelUrl: formData.modelUrl || "",
        videoUrl: formData.videoUrl || "",
      };

      if (imageUrls.length > 0) {
        productData.image = imageUrls[0];
        productData.images = imageUrls;
      } else if (!editingId) {
        // Auto-generate dynamic SVG part artwork based on name & category
        const autoPartImg = generatePartSvg(
          formData.name,
          formData.category === "Custom" ? formData.customCategory : formData.category
        );
        productData.image = autoPartImg;
        productData.images = [autoPartImg];
        productData.isAutoGeneratedImage = true;
      }

      if (editingId) {
        await updateDoc(doc(db, "products", editingId), productData);
        notify("Product updated successfully", "success");
      } else {
        productData.rating = 5;
        productData.numReviews = 0;
        await addDoc(collection(db, "products"), productData);
        notify("Product added to catalog (Auto Image generated if none uploaded)", "success");
      }

      setIsAdding(false);
      setEditingId(null);
      setFormData({
        name: "",
        price: 0,
        resellerPrice: 0,
        description: "",
        category: "Mobile",
        customCategory: "",
        stock: 10,
        imageFiles: [],
        isOffer: false,
        offerPrice: 0,
        productType: "normal",
        advanceAmount: 0,
        modelUrl: "",
        videoUrl: "",
      });
      fetchProducts();
    } catch (err: any) {
      notify(err.message || "Failed to save product", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    confirm({
      title: "Delete Product?",
      message: "This product will be permanently removed from the store.",
      onConfirm: async () => {
        await deleteDoc(doc(db, "products", id));
        notify("Product deleted", "info");
        fetchProducts();
      },
    });
  };

  return (
    <div className="max-w-[1440px] mx-auto px-6 md:px-12 py-10 min-h-screen bg-zinc-50 dark:bg-zinc-800 animate-fade-in relative overflow-hidden">
      <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900/5 rounded-full blur-[100px] pointer-events-none z-0"></div>
      <div className="flex items-center justify-between mb-12 relative z-10 animate-stagger-1">
        <div className="flex items-center space-x-6">
          <div>
            <h1 className="text-xl md:text-lg font-semibold tracking-tight text-zinc-900 dark:text-zinc-100 mb-1.5 text-shine">
              Products Inventory
            </h1>
            <p className="text-zinc-400 text-[10px] md:text-xs font-bold tracking-normal ">
              Catalog Management
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            setIsAdding(!isAdding);
            setEditingId(null);
            setFormData({
              name: "",
              price: 0,
              description: "",
              category: "Mobile",
              customCategory: "",
              stock: 10,
              imageFiles: [],
              isOffer: false,
              offerPrice: 0,
              modelUrl: "",
              videoUrl: "",
            });
          }}
          className={`px-6 py-3 rounded-full font-bold  text-[10px] tracking-normal shadow-lg transition-all active:scale-95 border hover-tilt hover-glow ${isAdding ? "bg-zinc-50 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:bg-zinc-800" : "bg-zinc-900 text-white border-zinc-900 hover:bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900"}`}
        >
          {isAdding ? "Cancel" : "Add Product"}
        </button>
      </div>

      <Modal
        isOpen={isAdding}
        onClose={() => {
          setIsAdding(false);
          setEditingId(null);
        }}
        title={editingId ? "Edit Product" : "Add New Product"}
        animationType="scale"
      >
        <form onSubmit={handleSubmit} className="w-full space-y-4">
          <div className="space-y-4 md:space-y-6">
            <div className="md:flex md:items-center md:space-x-4">
              <div className="md:w-1/2">
                <Label htmlFor="name" className="font-medium text-xs text-zinc-500 mb-2 block">
                  Product Name
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="mt-4 md:mt-0 md:w-1/2">
                <Label htmlFor="category" className="font-medium text-xs text-zinc-500 mb-2 block">
                  Category
                </Label>
                <div className="flex gap-2">
                <select
                  id="category"
                  className="w-full bg-zinc-50 dark:bg-[#121212] p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 outline-none text-sm appearance-none cursor-pointer"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                >
                  {Array.from(new Set([
                    "Phone Parts (পার্টস)",
                    "Display (ডিসপ্লে)",
                    "Battery (ব্যাটারি)",
                    "Camera (ক্যামেরা)",
                    "Logic Board (মাদারবোর্ড)",
                    "Mobile",
                    "Border Cross",
                    "Mobiles",
                    "Original Phones",
                    "Chargers",
                    ...products.map((p) => p.category).filter(Boolean)
                  ])).filter(cat => cat !== "Gadgets" && cat !== "Accessories").map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                  <option value="Custom">Custom...</option>
                </select>
                {formData.category === "Custom" && (
                  <Input
                    placeholder="Enter Custom Category..."
                    value={formData.customCategory}
                    onChange={(e) => setFormData({ ...formData, customCategory: e.target.value })}
                    required
                  />
                )}
                </div>
              </div>
            </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="price" className="font-medium text-xs text-zinc-500 mb-2 block">
                        Regular Price (৳)
                      </Label>
                      <Input
                        id="price"
                        type="number"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                        required
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label htmlFor="resellerPrice" className="font-medium text-xs text-amber-600 dark:text-amber-400 block font-bold">
                          Reseller Price (৳)
                        </Label>
                        <span className="text-[10px] text-zinc-400">Exclusive</span>
                      </div>
                      <Input
                        id="resellerPrice"
                        type="number"
                        placeholder="e.g. 18000"
                        className="border-amber-500/40 focus:border-amber-500"
                        value={formData.resellerPrice || ""}
                        onChange={(e) => setFormData({ ...formData, resellerPrice: Number(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="stock" className="font-medium text-xs text-zinc-500 mb-2 block">
                        Stock Amount
                      </Label>
                      <Input
                        id="stock"
                        type="number"
                        value={formData.stock}
                        onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label className="font-medium text-xs text-zinc-500 block">
                        Upload Images (অপশনাল)
                      </Label>
                      {formData.name.trim().length > 0 && formData.imageFiles.length === 0 && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                          <Sparkles className="w-3 h-3" /> Auto Dynamic Artwork Active
                        </span>
                      )}
                    </div>
                    <Input
                      type="file"
                      accept="image/*"
                      multiple
                      className="cursor-pointer file:cursor-pointer"
                      onChange={(e) => {
                        if (e.target.files)
                          setFormData({
                            ...formData,
                            imageFiles: Array.from(e.target.files),
                          });
                      }}
                    />
                    {editingId ? (
                      <p className="mt-2 text-xs text-muted-foreground">
                        Leave empty to keep existing images.
                      </p>
                    ) : (
                      <div className="mt-2.5 p-3 rounded-xl bg-zinc-100/80 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700/60 flex items-start gap-3">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-black shrink-0 border border-zinc-700 shadow-sm flex items-center justify-center">
                          <img
                            src={generatePartSvg(formData.name || "Mobile Phone Part", formData.category === "Custom" ? formData.customCategory : formData.category)}
                            alt="Preview"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[11px] font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-amber-500" />
                            অটো ডাইনামিক ইমেজ সিস্টেম:
                          </p>
                          <p className="text-[10px] text-zinc-500 dark:text-zinc-400 mt-0.5 leading-relaxed">
                            আপনি ছবি আপলোড না করলেও টাইটেল অনুযায়ী (Display, Battery, Camera, Logic) হাই-কোয়ালিটি ব্র্যান্ডেড ইমেজ ও ফোন মডেল অটোমেটিকভাবে জেনারেট হয়ে যাবে!
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="md:flex md:items-center md:space-x-4">
                    <div className="md:w-1/2">
                      <Label htmlFor="modelUrl" className="font-medium text-xs text-zinc-500 mb-2 block">
                        3D Model URL (GLB)
                      </Label>
                      <Input
                        id="modelUrl"
                        type="url"
                        placeholder="https://example.com/model.glb"
                        value={formData.modelUrl || ""}
                        onChange={(e) => setFormData({ ...formData, modelUrl: e.target.value })}
                      />
                    </div>
                    <div className="mt-4 md:mt-0 md:w-1/2">
                      <Label htmlFor="videoUrl" className="font-medium text-xs text-zinc-500 mb-2 block">
                        Video Review URL
                      </Label>
                      <Input
                        id="videoUrl"
                        type="url"
                        placeholder="https://youtube.com/watch?v=..."
                        value={formData.videoUrl || ""}
                        onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                      />
                    </div>
                  </div>

                  {/* Product Type & Advance Policy */}
                  <div className="space-y-3 p-4 bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl border border-zinc-200 dark:border-zinc-700">
                    <Label className="font-bold text-xs text-zinc-700 dark:text-zinc-300 block">
                      Product Type & Advance Payment Policy (প্রোডাক্ট ধরণ ও এডভান্স রুলস)
                    </Label>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, productType: "normal", isOffer: false })}
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1 ${
                          formData.productType === "normal"
                            ? "border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-2 ring-blue-500/20"
                            : "border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300"
                        }`}
                      >
                        <span>📦 Normal Border</span>
                        <span className="text-[10px] font-normal opacity-80">Half (50%)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, productType: "offer", isOffer: true })}
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1 ${
                          formData.productType === "offer"
                            ? "border-red-500 bg-red-500/10 text-red-600 dark:text-red-400 ring-2 ring-red-500/20"
                            : "border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300"
                        }`}
                      >
                        <span>🔥 Offer Product</span>
                        <span className="text-[10px] font-normal opacity-80">Full (100%)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, productType: "bypass", isOffer: false })}
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1 ${
                          formData.productType === "bypass"
                            ? "border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-2 ring-emerald-500/20"
                            : "border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300"
                        }`}
                      >
                        <span>⚡ Bypass Product</span>
                        <span className="text-[10px] font-normal opacity-80">COD (0 Advance)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, productType: "custom", isOffer: false })}
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-1 ${
                          formData.productType === "custom"
                            ? "border-[#EF8020] bg-[#EF8020]/10 text-[#EF8020] ring-2 ring-[#EF8020]/20"
                            : "border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300"
                        }`}
                      >
                        <span>🏷️ Custom Advance</span>
                        <span className="text-[10px] font-normal opacity-80">Specific Amount</span>
                      </button>
                    </div>

                    {formData.productType === "offer" && (
                      <div className="pt-2">
                        <Label htmlFor="offerPrice" className="font-medium text-xs text-red-500 mb-1 block">
                          Offer Price (৳)
                        </Label>
                        <Input
                          id="offerPrice"
                          type="number"
                          placeholder="e.g. 990"
                          value={formData.offerPrice || ""}
                          onChange={(e) => setFormData({ ...formData, offerPrice: Number(e.target.value) })}
                          className="border-red-200 focus-visible:ring-red-200 h-10 text-xs bg-white dark:bg-zinc-900"
                        />
                      </div>
                    )}

                    {formData.productType === "custom" && (
                      <div className="pt-2">
                        <Label htmlFor="customAdvAmount" className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1 block">
                          Custom Advance Amount (৳)
                        </Label>
                        <Input
                          id="customAdvAmount"
                          type="number"
                          placeholder="e.g. 500"
                          value={formData.advanceAmount || ""}
                          onChange={(e) => setFormData({ ...formData, advanceAmount: Number(e.target.value) })}
                          className="h-10 text-xs bg-white dark:bg-zinc-900"
                        />
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="description" className="font-medium text-xs text-zinc-500 mb-2 block">
                      Product Description
                    </Label>
                    <Textarea
                      id="description"
                      className="min-h-[140px]"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>
                </div>
                
                <Separator className="my-8" />
                <div className="flex items-center gap-4 justify-end">
                  <Button type="button" variant="ghost" onClick={() => setIsAdding(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={loading} className="px-8 bg-zinc-900 hover:bg-zinc-800 text-white rounded-full">
                    {loading ? "Processing..." : editingId ? "Update Product" : "Save Product"}
                  </Button>
                </div>
              </form>
            </Modal>

      <div className="flex flex-col space-y-3 relative z-10 animate-stagger-3 max-w-4xl mx-auto">
        <ItemGroup className="flex flex-col gap-4">
          {products.map((p) => (
            <Item key={p.id} variant="outline" className="group">
              <ItemMedia variant="image" className="size-16 md:size-20 shrink-0 border border-border p-2 bg-pink-50 dark:bg-zinc-800 rounded-md">
                <img src={p.image} className="w-full h-full object-contain mix-blend-multiply dark:mix-blend-normal" alt={p.name} />
              </ItemMedia>
              <ItemContent>
                <ItemTitle className="max-w-[200px] md:max-w-md truncate">{p.name}</ItemTitle>
                <ItemDescription className="font-medium flex items-center flex-wrap gap-x-2 mt-1">
                  <span>৳{p.isOffer && p.offerPrice ? p.offerPrice : p.price}</span>
                  <span>•</span>
                  <span>{p.stock} in stock</span>
                  {p.isOffer && (
                    <>
                       <span>•</span>
                       <span className="text-red-500 font-bold">Offer</span>
                    </>
                  )}
                </ItemDescription>
              </ItemContent>
              <ItemActions className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity justify-end shrink-0 ml-auto">
                <Button size="icon" variant="secondary" className="h-9 w-9 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700" onClick={() => handleEdit(p)}>
                  <Pen className="size-4" />
                </Button>
                <Button size="icon" variant="destructive" className="h-9 w-9 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/40 text-red-500" onClick={() => handleDelete(p.id)}>
                  <Trash2 className="size-4" />
                </Button>
              </ItemActions>
            </Item>
          ))}
          {products.length === 0 && (
            <div className="py-32 text-center flex flex-col items-center bg-zinc-50 dark:bg-zinc-800 rounded-2xl border border-zinc-100 dark:border-zinc-800 shadow-sm">
              <Box className="w-8 h-8 text-zinc-300 mb-4" />
              <p className="text-zinc-400 font-bold tracking-normal text-xs">
                Inventory is empty
              </p>
            </div>
          )}
        </ItemGroup>
      </div>
    </div>
  );
};

export default ManageProducts;
