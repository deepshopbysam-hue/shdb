import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Users, ShoppingBag, Bell, Send, Plus, ThumbsUp, 
  MessageSquare, Bookmark, MoreHorizontal, ArrowUpRight, 
  Search, X, Check, Share2, Trash2, Edit3, ShieldAlert,
  Upload, Image as ImageIcon, Home, User, ShieldCheck,
  PhoneCall, TrendingUp, AlertTriangle
} from "lucide-react";
import { collection, onSnapshot, query, orderBy, doc, deleteDoc, updateDoc, increment } from "firebase/firestore";
import { db, auth } from "../firebase";
import { NewsPost } from "../types";
import { useNotify } from "../components/Notifications";
import { NewsBottomNav } from "../components/news/NewsBottomNav";
import { applyWatermarkToImage } from "@/src/lib/watermark";
import { uploadToImgbb } from "../services/imgbb";
import { VerifiedBadgeIcon } from "../components/SellerBadge";

// Raw, realistic Vigilance & Tech Demo Reports (No beauty/skincare)
const DEMO_POST_1: NewsPost = {
  id: "scam_alert_fake_gadget_point",
  title: "🚨 SCAM ALERT: Fake Seller 'Gadget Point' reported for ৳15,000 bKash fraud",
  content: "Customer was promised an authentic border cross phone with 50% advance through personal bKash 01799887766. After payment was transferred, the seller blocked the phone number and WhatsApp immediately. Evidence screenshots attached.",
  category: "Scam Alert",
  tags: ["#scamalert", "#fraud", "#fakeadvance", "#borderphone"],
  authorId: "deep_vigilance",
  authorName: "Deep Shop Vigilance",
  authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80",
  isAuthorVerified: true,
  coverImage: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80",
  images: ["https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80"],
  createdAt: Date.now() - 3600 * 1000 * 3,
  publishedAtStr: "3h ago",
  views: 142,
  status: "published",
  isScamReport: true,
  scammerName: "Rakibul Islam (Gadget Point)",
  scammerPhone: "01799887766",
  scammedAmount: 15000,
  totalReactions: 14,
  commentsCount: 5,
  reactions: { like: 14, userReactions: {} },
};

const DEMO_POST_2: NewsPost = {
  id: "border_phone_imei_verification_guide",
  title: "📱 Official IMEI Portal Check: How to identify authentic Border Cross Devices",
  content: "Step-by-step instructions for verifying genuine imported border cross phones before transferring any courier advance. Always demand a live video inspection of the physical IMEI and avoid personal unverified payment numbers.",
  category: "News Report",
  tags: ["#borderphone", "#imeicheck", "#safecommerce", "#authenticdevice"],
  authorId: "deep_tech_editor",
  authorName: "Tech Desk (Deep Shop)",
  authorAvatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=160&auto=format&fit=crop&q=80",
  isAuthorVerified: true,
  coverImage: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&auto=format&fit=crop&q=80",
  images: ["https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&auto=format&fit=crop&q=80"],
  createdAt: Date.now() - 3600 * 1000 * 12,
  publishedAtStr: "12h ago",
  views: 289,
  status: "published",
  totalReactions: 23,
  commentsCount: 8,
  reactions: { like: 23, userReactions: {} },
};

// Vigilance & Tech Hashtags (Strictly authentic commerce & fraud prevention)
const TRENDING_TAGS = [
  "#scamalert",
  "#fakeadvance",
  "#bkashfraud",
  "#borderphone",
  "#imeicheck",
  "#safecommerce",
  "#fraudexposed",
  "#deepshopalert"
];

export const NewsHub: React.FC = () => {
  const navigate = useNavigate();
  const notify = useNotify();
  const currentUser = auth.currentUser;

  const [posts, setPosts] = useState<NewsPost[]>([]);
  const [activeTab, setActiveTab] = useState<"home" | "scams" | "saved" | "moderation">("home");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [savedPostIds, setSavedPostIds] = useState<Record<string, boolean>>(() => {
    try {
      const stored = localStorage.getItem("deepshop_saved_news_ids");
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });
  const [activeMenuPostId, setActiveMenuPostId] = useState<string | null>(null);

  // Stealth Admin Edit State
  const [editingPost, setEditingPost] = useState<NewsPost | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");
  const [editTags, setEditTags] = useState("");
  const [editImages, setEditImages] = useState<string[]>([]);
  const [isUploadingEditImage, setIsUploadingEditImage] = useState(false);

  const isAdmin = currentUser?.email === "claimfaf@gmail.com" || 
                  currentUser?.email === "admin@deep.shop" || 
                  currentUser?.email === "deepshop@gmail.com" ||
                  currentUser?.email === "zixpower74@gmail.com";

  // Real-time Firestore sync
  useEffect(() => {
    const q = query(collection(db, "news_posts"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const fetched = snapshot.docs.map((docSnap) => ({
          id: docSnap.id,
          ...docSnap.data(),
        })) as NewsPost[];

        const visible = fetched.filter((p) => {
          if (p.status === "published") return true;
          if (isAdmin) return true;
          if (currentUser && p.authorId === currentUser.uid) return true;
          return false;
        });

        const merged = [DEMO_POST_1, DEMO_POST_2, ...visible.filter(p => p.id !== DEMO_POST_1.id && p.id !== DEMO_POST_2.id)];
        setPosts(merged);
      },
      () => {
        setPosts([DEMO_POST_1, DEMO_POST_2]);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid, isAdmin]);

  // Persist Bookmark in localStorage
  const handleToggleBookmark = (e: React.MouseEvent, postId: string) => {
    e.stopPropagation();
    setSavedPostIds((prev) => {
      const isSaved = !!prev[postId];
      const next = { ...prev, [postId]: !isSaved };
      try {
        localStorage.setItem("deepshop_saved_news_ids", JSON.stringify(next));
      } catch (err) {
        console.error(err);
      }
      notify(isSaved ? "Removed from bookmarks" : "Saved to bookmarks!", "success");
      return next;
    });
  };

  // 1 Like Per User ID strictly enforced
  const handleLikePost = async (e: React.MouseEvent, post: NewsPost) => {
    e.stopPropagation();
    if (!currentUser) {
      notify("Please sign in to react to this report", "info");
      navigate("/signin");
      return;
    }

    const currentReaction = post.reactions?.userReactions?.[currentUser.uid];
    const isLiked = currentReaction === "like";

    if (post.id === DEMO_POST_1.id || post.id === DEMO_POST_2.id) {
      setPosts((prev) =>
        prev.map((p) => {
          if (p.id === post.id) {
            const currentCount = p.reactions?.like || 0;
            return {
              ...p,
              reactions: {
                ...p.reactions,
                like: isLiked ? Math.max(0, currentCount - 1) : currentCount + 1,
                userReactions: {
                  ...p.reactions?.userReactions,
                  [currentUser.uid]: isLiked ? "" : "like"
                }
              }
            };
          }
          return p;
        })
      );
      notify(isLiked ? "Like removed" : "Liked!", "success");
      return;
    }

    try {
      const postRef = doc(db, "news_posts", post.id);
      await updateDoc(postRef, {
        "reactions.like": increment(isLiked ? -1 : 1),
        [`reactions.userReactions.${currentUser.uid}`]: isLiked ? "" : "like"
      });
      notify(isLiked ? "Like removed" : "Liked!", "success");
    } catch {
      notify("Could not update reaction", "error");
    }
  };

  // Stealth Admin Open Edit Post
  const handleOpenEdit = (e: React.MouseEvent, post: NewsPost) => {
    e.stopPropagation();
    setEditingPost(post);
    setEditTitle(post.title || "");
    setEditContent(post.content || "");
    setEditTags((post.tags || []).join(", "));
    setEditImages(post.images && post.images.length > 0 ? [...post.images] : post.coverImage ? [post.coverImage] : []);
    setActiveMenuPostId(null);
  };

  // Stealth Admin Upload Image for Post
  const handleAdminImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingEditImage(true);
    try {
      const { file: stampedFile } = await applyWatermarkToImage(file, {
        watermarkText: "Revealed On DEEP SHOP",
        subText: "OFFICIAL VIGILANCE REPORT",
        opacity: 0.25,
      });

      const uploadedUrl = await uploadToImgbb(stampedFile);
      setEditImages((prev) => [...prev, uploadedUrl]);
      notify("Watermarked image attached!", "success");
    } catch {
      notify("Failed to watermark image", "error");
    } finally {
      setIsUploadingEditImage(false);
    }
  };

  // Stealth Admin Remove Image
  const handleRemoveEditImage = (indexToRemove: number) => {
    setEditImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  // Stealth Admin Save Edit
  const handleSaveEdit = async () => {
    if (!editingPost) return;
    try {
      const tagsArray = editTags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
        .map((t) => (t.startsWith("#") ? t : `#${t}`));

      if (editingPost.id !== DEMO_POST_1.id && editingPost.id !== DEMO_POST_2.id) {
        await updateDoc(doc(db, "news_posts", editingPost.id), {
          title: editTitle.trim(),
          content: editContent.trim(),
          tags: tagsArray,
          images: editImages,
          coverImage: editImages[0] || "",
          updatedAt: Date.now(),
        });
      }

      setPosts((prev) =>
        prev.map((p) =>
          p.id === editingPost.id
            ? { 
                ...p, 
                title: editTitle.trim(), 
                content: editContent.trim(), 
                tags: tagsArray,
                images: editImages,
                coverImage: editImages[0] || ""
              }
            : p
        )
      );

      notify("Post updated quietly", "success");
      setEditingPost(null);
    } catch {
      notify("Failed to update post", "error");
    }
  };

  // Stealth Admin Delete
  const handleDeletePost = async (e: React.MouseEvent, postId: string) => {
    e.stopPropagation();
    if (!window.confirm("Permanently remove this report?")) return;
    try {
      if (postId !== DEMO_POST_1.id && postId !== DEMO_POST_2.id) {
        await deleteDoc(doc(db, "news_posts", postId));
      }
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      notify("Post removed", "success");
      setActiveMenuPostId(null);
    } catch {
      notify("Failed to remove post", "error");
    }
  };

  // Stealth Admin Approve Post from moderation
  const handleApprovePost = async (e: React.MouseEvent, postId: string) => {
    e.stopPropagation();
    try {
      await updateDoc(doc(db, "news_posts", postId), {
        status: "published",
      });
      setPosts((prev) =>
        prev.map((p) => (p.id === postId ? { ...p, status: "published" } : p))
      );
      notify("Report approved and published to all members!", "success");
    } catch {
      notify("Failed to approve report", "error");
    }
  };

  // Filter posts based on activeTab, selectedTag, and searchQuery
  const filteredPosts = posts.filter((p) => {
    // 0. Moderation Tab Filter (Admin only)
    if (activeTab === "moderation") {
      return p.status === "pending_admin_review";
    }

    // 1. Saved Tab Filter
    if (activeTab === "saved") {
      if (!savedPostIds[p.id]) return false;
    }

    // 2. Scams Tab Filter
    if (activeTab === "scams") {
      if (!p.isScamReport && p.category !== "Scam Alert") return false;
    }

    // 3. Tag Filter
    if (selectedTag) {
      const hasTag = (p.tags || []).some(
        (t) => t.toLowerCase() === selectedTag.toLowerCase()
      );
      const inTitle = (p.title || "").toLowerCase().includes(selectedTag.replace("#", "").toLowerCase());
      if (!hasTag && !inTitle) return false;
    }

    // 4. Search Filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchTitle = (p.title || "").toLowerCase().includes(q);
      const matchContent = (p.content || "").toLowerCase().includes(q);
      const matchAuthor = (p.authorName || "").toLowerCase().includes(q);
      const matchPhone = (p.scammerPhone || "").toLowerCase().includes(q);
      if (!matchTitle && !matchContent && !matchAuthor && !matchPhone) return false;
    }

    return true;
  });

  const featuredPosts = filteredPosts.slice(0, 4);
  const expertPicks = filteredPosts.slice(0);

  // Require account to create post
  const handleCreateReportClick = () => {
    if (!currentUser) {
      notify("Please sign in with your account to report fraud or post news", "warning");
      navigate("/signin", { state: { from: "/news-hub/create" } });
      return;
    }
    navigate("/news-hub/create");
  };

  return (
    <div className="min-h-screen bg-white dark:bg-black text-zinc-900 dark:text-zinc-100 pb-28 select-none font-sans">
      {/* Top Header Bar - Full Width Responsive Container */}
      <div className="sticky top-0 z-30 bg-white/95 dark:bg-black/95 backdrop-blur-md px-4 sm:px-6 lg:px-8 py-3 border-b border-zinc-200/70 dark:border-zinc-800/80">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Left: Segmented Capsule Switch [ Vigilance | Shop ] + Desktop Title */}
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-[#ededed] dark:bg-zinc-800/90 p-1 rounded-full shadow-inner shrink-0">
              <button
                type="button"
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white font-semibold text-[11px] shadow-xs cursor-pointer transition-all whitespace-nowrap"
              >
                <Users className="w-3.5 h-3.5 text-zinc-800 dark:text-zinc-200" />
                <span className="whitespace-nowrap">Vigilance</span>
              </button>
              <button
                type="button"
                onClick={() => navigate("/")}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 font-medium text-[11px] cursor-pointer transition-all whitespace-nowrap"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span className="whitespace-nowrap">Shop</span>
              </button>
            </div>
            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-zinc-200 dark:border-zinc-800">
              <span className="text-sm font-black text-zinc-900 dark:text-white tracking-tight flex items-center gap-1.5 whitespace-nowrap">
                <span className="w-2 h-2 rounded-full bg-[#86c857]" />
                Deep Shop Vigilance Hub
              </span>
            </div>
          </div>

          {/* Desktop Direct Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search fraud phone numbers, fake pages, IMEI alerts..."
                className="w-full pl-9 pr-8 py-2 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none focus:ring-1 focus:ring-[#86c857] shadow-xs"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2">
            {/* Desktop Report Button */}
            <button
              type="button"
              onClick={handleCreateReportClick}
              className="hidden md:flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#86c857] hover:bg-[#78be4a] text-white font-bold text-xs shadow-sm transition active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Report Scam</span>
            </button>

            {/* Mobile Search Toggle */}
            <button
              type="button"
              onClick={() => setShowSearch(!showSearch)}
              className="md:hidden w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 shadow-xs hover:bg-zinc-50 active:scale-95 transition cursor-pointer"
              title="Search Reports & Scammers"
            >
              <Search className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => navigate("/notifications")}
              className="w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 shadow-xs hover:bg-zinc-50 active:scale-95 transition cursor-pointer relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="w-2 h-2 rounded-full bg-[#86c857] absolute top-2 right-2 ring-2 ring-white dark:ring-zinc-900" />
            </button>

            <button
              type="button"
              onClick={() => navigate("/messages")}
              className="w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300 shadow-xs hover:bg-zinc-50 active:scale-95 transition cursor-pointer"
              title="Helpline & Direct Chat"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Expandable Mobile Search Input */}
      {showSearch && (
        <div className="md:hidden max-w-xl mx-auto px-4 py-2">
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search fraud numbers, fake pages, IMEI alerts..."
              autoFocus
              className="w-full pl-9 pr-8 py-2 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none focus:ring-1 focus:ring-[#86c857] shadow-xs"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* RESPONSIVE MAIN CONTAINER (Sidebar Navigation + Feed + Info Panel) */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 flex items-start gap-6 lg:gap-8">
        {/* DESKTOP LEFT SIDEBAR: Nav + Filters (Desktop navigation replacing mobile bottom nav) */}
        <aside className="hidden md:flex flex-col w-56 lg:w-64 shrink-0 sticky top-20 space-y-4 select-none">
          {/* Navigation Card */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-3 border border-zinc-200/70 dark:border-zinc-800 shadow-xs space-y-1">
            <button
              type="button"
              onClick={() => {
                setActiveTab("home");
                setSelectedTag(null);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === "home" && !selectedTag
                  ? "bg-[#86c857] text-white shadow-xs"
                  : "text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              }`}
            >
              <Home className="w-4 h-4 shrink-0" />
              <span className="whitespace-nowrap">All Reports Feed</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab("scams");
                setSelectedTag(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === "scams"
                  ? "bg-red-600 text-white shadow-xs"
                  : "text-zinc-700 dark:text-zinc-300 hover:bg-red-50 dark:hover:bg-red-950/40 hover:text-red-600"
              }`}
            >
              <span className="flex items-center gap-3">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span className="whitespace-nowrap">Scam Alerts</span>
              </span>
              <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-red-100 dark:bg-red-900/60 text-red-600 dark:text-red-200 font-black">
                Live
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab("saved");
                setSelectedTag(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === "saved"
                  ? "bg-[#86c857] text-white shadow-xs"
                  : "text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              }`}
            >
              <span className="flex items-center gap-3">
                <Bookmark className="w-4 h-4 shrink-0" />
                <span className="whitespace-nowrap">Saved Bookmarks</span>
              </span>
              <span className="text-[11px] font-mono opacity-80">
                {Object.values(savedPostIds).filter(Boolean).length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => navigate(currentUser ? `/news-hub/user/${encodeURIComponent(currentUser.uid)}` : "/profile")}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-bold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all cursor-pointer"
            >
              <User className="w-4 h-4 shrink-0" />
              <span className="whitespace-nowrap">My News Profile</span>
            </button>
          </div>

          {/* Desktop Post CTA Button */}
          <button
            type="button"
            onClick={handleCreateReportClick}
            className="w-full py-3 rounded-2xl bg-[#86c857] hover:bg-[#78be4a] text-white font-bold text-xs shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Submit Scam or Post</span>
          </button>

          {/* Trending Tags Section in Sidebar */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-4 border border-zinc-200/70 dark:border-zinc-800 shadow-xs space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-[#86c857]" />
              <span>Trending Tags</span>
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {TRENDING_TAGS.map((tag) => {
                const isActive = selectedTag === tag;
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => setSelectedTag(isActive ? null : tag)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-semibold transition-all cursor-pointer whitespace-nowrap leading-none ${
                      isActive
                        ? "bg-[#86c857] text-white shadow-xs"
                        : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700"
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Safety Hotline Card */}
          <div className="bg-gradient-to-br from-red-50 to-amber-50 dark:from-red-950/30 dark:to-zinc-900 rounded-3xl p-4 border border-red-200/70 dark:border-red-900/40 text-xs space-y-2">
            <div className="flex items-center gap-2 text-red-600 font-bold text-xs uppercase tracking-wide">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>Cyber Fraud Hotline</span>
            </div>
            <p className="text-[11px] text-zinc-600 dark:text-zinc-300 leading-relaxed">
              Encountered advance bKash/Nagad fraud? Reach Deep Shop Trust & Safety team immediately.
            </p>
            <button
              type="button"
              onClick={() => navigate("/messages")}
              className="w-full py-1.5 px-3 rounded-full bg-white dark:bg-zinc-800 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-300 text-[11px] font-bold text-center hover:bg-red-50 transition cursor-pointer"
            >
              Contact Support 24/7
            </button>
          </div>
        </aside>

        {/* CENTER COLUMN: Main Feed and Community Reports */}
        <main className="flex-1 min-w-0 max-w-2xl lg:max-w-3xl space-y-5 bg-white dark:bg-black">
          {/* Active Tab indicator if in Saved or Scams */}
          {activeTab !== "home" && (
            <div className="px-1 pt-1 pb-1 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="px-3 py-1 rounded-full bg-[#86c857]/15 text-[#6aa843] font-bold text-xs flex items-center gap-1.5 whitespace-nowrap">
                  {activeTab === "saved" ? <Bookmark className="w-3.5 h-3.5" /> : <ShieldAlert className="w-3.5 h-3.5" />}
                  <span>{activeTab === "saved" ? "Saved Reports" : "Scam Alerts Only"}</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab("home")}
                className="text-xs text-zinc-500 hover:text-zinc-900 dark:hover:text-white font-medium"
              >
                Back to All
              </button>
            </div>
          )}

          {/* Active Filter Pill Bar if filtered by Tag */}
          {selectedTag && (
            <div className="px-1 pt-1 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-[11px] text-zinc-500 whitespace-nowrap">Tag:</span>
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-[11px] font-semibold whitespace-nowrap">
                {selectedTag}
                <button
                  type="button"
                  onClick={() => setSelectedTag(null)}
                  className="hover:text-zinc-900 dark:hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            </div>
          )}
        {/* Empty state for Saved */}
        {activeTab === "saved" && filteredPosts.length === 0 && (
          <div className="p-8 text-center bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/70 dark:border-zinc-800 mx-4 space-y-3">
            <Bookmark className="w-10 h-10 text-zinc-300 mx-auto" />
            <h3 className="font-bold text-sm text-zinc-900 dark:text-white">No Saved Reports Yet</h3>
            <p className="text-xs text-zinc-500 max-w-xs mx-auto">
              Click the bookmark icon on any scam alert or news discussion to save it here for quick access.
            </p>
            <button
              type="button"
              onClick={() => setActiveTab("home")}
              className="px-4 py-2 rounded-full bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 text-xs font-bold shadow-sm"
            >
              Browse News Hub
            </button>
          </div>
        )}

        {/* Section 1: Featured Reports / Discussions */}
        {filteredPosts.length > 0 && (
          <div className="space-y-3">
            <div className="px-4 flex items-center justify-between">
              <h2 className="text-base sm:text-[17px] font-bold text-zinc-900 dark:text-white tracking-tight">
                {activeTab === "saved" ? "Your Bookmarked Reports" : activeTab === "scams" ? "Verified Scam Alerts" : "Featured Reports & Alerts"}
              </h2>
              <button
                type="button"
                onClick={() => {
                  setActiveTab("home");
                  setSelectedTag(null);
                }}
                className="flex items-center gap-0.5 text-xs font-semibold text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 cursor-pointer transition-colors"
              >
                <span className="whitespace-nowrap">Explore</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Horizontal Snap Scroll Cards Slider */}
            <div className="flex items-stretch gap-3.5 overflow-x-auto no-scrollbar px-4 py-1 snap-x snap-mandatory">
              {featuredPosts.map((post) => {
                const isSaved = !!savedPostIds[post.id];
                const rawLikeCount = post.reactions?.like ?? post.totalReactions ?? 0;
                const rawCommentsCount = post.commentsCount ?? 0;
                const isUserLiked = currentUser && post.reactions?.userReactions?.[currentUser.uid] === "like";
                const postImage = post.coverImage || post.images?.[0];

                return (
                  <div
                    key={post.id}
                    onClick={() => navigate(`/news-hub/${post.id}`)}
                    className="w-[285px] sm:w-[315px] shrink-0 snap-start bg-white dark:bg-zinc-900 rounded-[22px] p-4 border border-zinc-200/60 dark:border-zinc-800 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      {/* Top User Info Row */}
                      <div className="flex items-center justify-between gap-2">
                        <div 
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/news-hub/user/${encodeURIComponent(post.authorId || post.authorName)}`, {
                              state: {
                                authorName: post.authorName,
                                authorAvatar: post.authorAvatar,
                                isVerified: post.isAuthorVerified,
                                isAdmin: post.authorName?.toLowerCase().includes("deep") || post.authorName?.toLowerCase().includes("tech"),
                                isSeller: post.authorName?.toLowerCase().includes("gadget") || post.authorName?.toLowerCase().includes("seller"),
                              }
                            });
                          }}
                          className="flex items-center gap-2 cursor-pointer hover:opacity-85 transition group"
                        >
                          {post.authorAvatar ? (
                            <img
                              src={post.authorAvatar}
                              alt={post.authorName}
                              className="w-9 h-9 rounded-full object-cover bg-zinc-100 ring-1 ring-zinc-200 dark:ring-zinc-700 shrink-0"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-xs ring-1 ring-zinc-200 dark:ring-zinc-700 shrink-0">
                              {(post.authorName || "U")[0].toUpperCase()}
                            </div>
                          )}
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-xs font-bold text-zinc-900 dark:text-white leading-tight whitespace-nowrap group-hover:underline">
                              {post.authorName}
                            </span>
                            {post.isAuthorVerified && (
                              <VerifiedBadgeIcon className="w-3.5 h-3.5 shrink-0" />
                            )}
                            <span className="text-[11px] text-zinc-400 font-medium whitespace-nowrap">
                              • {post.publishedAtStr || "Recent"}
                            </span>
                          </div>
                        </div>

                        {/* Three-dots menu */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveMenuPostId(activeMenuPostId === post.id ? null : post.id);
                            }}
                            className="w-7 h-7 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 flex items-center justify-center transition"
                          >
                            <MoreHorizontal className="w-4 h-4" />
                          </button>

                          {activeMenuPostId === post.id && (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="absolute right-0 top-8 z-30 w-36 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-100 dark:border-zinc-800 py-1 text-xs text-zinc-700 dark:text-zinc-200"
                            >
                              <button
                                type="button"
                                onClick={(e) => {
                                  handleToggleBookmark(e, post.id);
                                  setActiveMenuPostId(null);
                                }}
                                className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                              >
                                <Bookmark className="w-3.5 h-3.5" />
                                <span className="whitespace-nowrap">{isSaved ? "Remove Bookmark" : "Bookmark"}</span>
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigator.clipboard.writeText(`${window.location.origin}/#/news-hub/${post.id}`);
                                  notify("Link copied to clipboard!", "success");
                                  setActiveMenuPostId(null);
                                }}
                                className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                              >
                                <Share2 className="w-3.5 h-3.5" />
                                <span className="whitespace-nowrap">Share Link</span>
                              </button>

                              {/* Stealth Admin Options */}
                              {isAdmin && (
                                <>
                                  {post.status === "pending_admin_review" && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        handleApprovePost(e, post.id);
                                        setActiveMenuPostId(null);
                                      }}
                                      className="w-full px-3 py-1.5 text-left text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 flex items-center gap-2 font-bold whitespace-nowrap"
                                    >
                                      <Check className="w-3.5 h-3.5" />
                                      <span className="whitespace-nowrap">Approve for All</span>
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={(e) => handleOpenEdit(e, post)}
                                    className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 border-t border-zinc-100 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200 whitespace-nowrap"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                    <span className="whitespace-nowrap">Edit Post</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => handleDeletePost(e, post.id)}
                                    className="w-full px-3 py-1.5 text-left hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 flex items-center gap-2 whitespace-nowrap"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span className="whitespace-nowrap">Delete Post</span>
                                  </button>
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Post Title */}
                      <h3 className="font-bold text-sm sm:text-[15px] text-zinc-900 dark:text-white mt-2.5 leading-snug line-clamp-2">
                        {post.title}
                      </h3>

                      {/* Post Excerpt */}
                      <p className="text-zinc-500 dark:text-zinc-400 text-xs line-clamp-2 mt-1 leading-relaxed">
                        {post.content}
                      </p>

                      {/* Attached Image Preview */}
                      {postImage && (
                        <div className="mt-2.5 rounded-xl overflow-hidden aspect-video w-full bg-zinc-100 dark:bg-zinc-800">
                          <img
                            src={postImage}
                            alt=""
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform hover:scale-105"
                          />
                        </div>
                      )}

                      {/* Single Line Hashtag Pills */}
                      <div className="flex items-center gap-1.5 flex-nowrap overflow-x-auto no-scrollbar mt-3">
                        {(post.tags || ["#scamalert", "#fraud"]).map((tag) => (
                          <span
                            key={tag}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedTag(tag);
                            }}
                            className="px-2.5 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-[10px] font-medium hover:bg-zinc-200 transition whitespace-nowrap shrink-0 leading-none"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Action Bar: Raw Real Counts */}
                    <div className="flex items-center justify-between pt-3.5 mt-3 border-t border-zinc-100 dark:border-zinc-800/80 text-zinc-500 dark:text-zinc-400">
                      <div className="flex items-center gap-4 text-xs font-semibold">
                        <button
                          type="button"
                          onClick={(e) => handleLikePost(e, post)}
                          className={`flex items-center gap-1.5 transition active:scale-95 whitespace-nowrap ${
                            isUserLiked ? "text-blue-600 font-bold" : "hover:text-zinc-900 dark:hover:text-white"
                          }`}
                        >
                          <ThumbsUp className={`w-3.5 h-3.5 ${isUserLiked ? "fill-current" : ""}`} />
                          <span>{rawLikeCount}</span>
                        </button>

                        <div className="flex items-center gap-1.5 whitespace-nowrap">
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{rawCommentsCount}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => handleToggleBookmark(e, post.id)}
                        className={`flex items-center gap-1 text-xs font-semibold transition active:scale-95 whitespace-nowrap ${
                          isSaved ? "text-[#86c857]" : "hover:text-zinc-900 dark:hover:text-white"
                        }`}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isSaved ? "fill-current" : ""}`} />
                        <span>{isSaved ? "Saved" : "Save"}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Section 2: Trending Fraud & Tech Vigilance Topics (No cosmetics/beauty) */}
        {activeTab === "home" && (
          <div className="px-4">
            <div className="rounded-[24px] bg-white dark:bg-black border border-zinc-200/80 dark:border-zinc-800 p-5 text-center shadow-xs">
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-white tracking-tight mb-3.5 whitespace-nowrap">
                Trending Vigilance Tags
              </h3>

              <div className="flex flex-wrap items-center justify-center gap-2 max-w-sm mx-auto">
                {TRENDING_TAGS.map((tag) => {
                  const isActive = selectedTag === tag;
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setSelectedTag(isActive ? null : tag)}
                      className={`px-3 py-1.5 rounded-full text-[11px] font-medium transition-all shadow-xs cursor-pointer whitespace-nowrap shrink-0 leading-none ${
                        isActive
                          ? "bg-[#86c857] text-white shadow-sm scale-105"
                          : "bg-zinc-50 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 border border-zinc-200/80 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 hover:scale-105 active:scale-95"
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Section 3: Verified Community Feed (Raw Counts) */}
        {filteredPosts.length > 0 && (
          <div className="space-y-3 px-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base sm:text-[17px] font-bold text-zinc-900 dark:text-white tracking-tight">
                {activeTab === "scams" ? "Active Investigation Reports" : "All Vigilance Reports"}
              </h2>
              <button
                type="button"
                onClick={() => {
                  setActiveTab("home");
                  setSelectedTag(null);
                }}
                className="flex items-center gap-0.5 text-xs font-semibold text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 cursor-pointer transition-colors"
              >
                <span className="whitespace-nowrap">Explore</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {expertPicks.map((post) => {
                const isSaved = !!savedPostIds[post.id];
                const rawLikeCount = post.reactions?.like ?? post.totalReactions ?? 0;
                const rawCommentsCount = post.commentsCount ?? 0;
                const isUserLiked = currentUser && post.reactions?.userReactions?.[currentUser.uid] === "like";
                const postImage = post.coverImage || post.images?.[0];

                return (
                  <div
                    key={post.id}
                    onClick={() => navigate(`/news-hub/${post.id}`)}
                    className="bg-white dark:bg-zinc-900 rounded-[22px] p-4 border border-zinc-200/60 dark:border-zinc-800 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-md transition-all cursor-pointer"
                  >
                    {/* Author Header */}
                    <div className="flex items-center justify-between gap-2">
                      <div 
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/news-hub/user/${encodeURIComponent(post.authorId || post.authorName)}`, {
                            state: {
                              authorName: post.authorName,
                              authorAvatar: post.authorAvatar,
                              isVerified: post.isAuthorVerified,
                              isAdmin: post.authorName?.toLowerCase().includes("deep") || post.authorName?.toLowerCase().includes("tech"),
                              isSeller: post.authorName?.toLowerCase().includes("gadget") || post.authorName?.toLowerCase().includes("seller"),
                            }
                          });
                        }}
                        className="flex items-center gap-2 cursor-pointer hover:opacity-85 transition group"
                      >
                        {post.authorAvatar ? (
                          <img
                            src={post.authorAvatar}
                            alt={post.authorName}
                            className="w-9 h-9 rounded-full object-cover bg-zinc-100 ring-1 ring-zinc-200 dark:ring-zinc-700 shrink-0"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-xs ring-1 ring-zinc-200 dark:ring-zinc-700 shrink-0">
                            {(post.authorName || "U")[0].toUpperCase()}
                          </div>
                        )}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-zinc-900 dark:text-white whitespace-nowrap group-hover:underline">
                            {post.authorName}
                          </span>
                          {post.isAuthorVerified && (
                            <VerifiedBadgeIcon className="w-3.5 h-3.5 shrink-0" />
                          )}
                          <span className="text-[11px] text-zinc-400 font-medium whitespace-nowrap">
                            • {post.publishedAtStr || "Recent"}
                          </span>
                        </div>
                      </div>

                      {/* Three-dots menu */}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMenuPostId(activeMenuPostId === post.id ? null : post.id);
                          }}
                          className="w-7 h-7 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 flex items-center justify-center transition"
                        >
                          <MoreHorizontal className="w-4 h-4" />
                        </button>

                        {activeMenuPostId === post.id && (
                          <div
                            onClick={(e) => e.stopPropagation()}
                            className="absolute right-0 top-8 z-30 w-36 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-100 dark:border-zinc-800 py-1 text-xs text-zinc-700 dark:text-zinc-200"
                          >
                            <button
                              type="button"
                              onClick={(e) => {
                                handleToggleBookmark(e, post.id);
                                setActiveMenuPostId(null);
                              }}
                              className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                            >
                              <Bookmark className="w-3.5 h-3.5" />
                              <span className="whitespace-nowrap">{isSaved ? "Remove Bookmark" : "Bookmark"}</span>
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigator.clipboard.writeText(`${window.location.origin}/#/news-hub/${post.id}`);
                                notify("Link copied to clipboard!", "success");
                                setActiveMenuPostId(null);
                              }}
                              className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                            >
                              <Share2 className="w-3.5 h-3.5" />
                              <span className="whitespace-nowrap">Share Link</span>
                            </button>

                            {isAdmin && (
                              <>
                                {post.status === "pending_admin_review" && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      handleApprovePost(e, post.id);
                                      setActiveMenuPostId(null);
                                    }}
                                    className="w-full px-3 py-1.5 text-left text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 flex items-center gap-2 font-bold whitespace-nowrap"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span className="whitespace-nowrap">Approve for All</span>
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={(e) => handleOpenEdit(e, post)}
                                  className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 border-t border-zinc-100 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200 whitespace-nowrap"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                  <span className="whitespace-nowrap">Edit Post</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => handleDeletePost(e, post.id)}
                                  className="w-full px-3 py-1.5 text-left hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 flex items-center gap-2 whitespace-nowrap"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span className="whitespace-nowrap">Delete Post</span>
                                </button>
                              </>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Post Title */}
                    <h3 className="font-bold text-sm sm:text-base text-zinc-900 dark:text-white mt-2.5 leading-snug">
                      {post.title}
                    </h3>

                    {/* Post Content */}
                    <p className="text-zinc-500 dark:text-zinc-400 text-xs sm:text-[13px] line-clamp-2 mt-1 leading-relaxed">
                      {post.content}
                    </p>

                    {/* Attached Image Preview */}
                    {postImage && (
                      <div className="mt-2.5 rounded-xl overflow-hidden aspect-video w-full bg-zinc-100 dark:bg-zinc-800">
                        <img
                          src={postImage}
                          alt=""
                          loading="lazy"
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                      </div>
                    )}

                    {/* Single Line Tags */}
                    <div className="flex items-center gap-1.5 flex-nowrap overflow-x-auto no-scrollbar mt-3">
                      {(post.tags || ["#scamalert", "#borderphone"]).map((tag) => (
                        <span
                          key={tag}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedTag(tag);
                          }}
                          className="px-2.5 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-[10px] font-medium hover:bg-zinc-200 transition whitespace-nowrap shrink-0 leading-none"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Action Bar: Raw Real Counts */}
                    <div className="flex items-center justify-between pt-3.5 mt-3 border-t border-zinc-100 dark:border-zinc-800/80 text-zinc-500 dark:text-zinc-400">
                      <div className="flex items-center gap-4 text-xs font-semibold">
                        <button
                          type="button"
                          onClick={(e) => handleLikePost(e, post)}
                          className={`flex items-center gap-1.5 transition active:scale-95 whitespace-nowrap ${
                            isUserLiked ? "text-blue-600 font-bold" : "hover:text-zinc-900 dark:hover:text-white"
                          }`}
                        >
                          <ThumbsUp className={`w-3.5 h-3.5 ${isUserLiked ? "fill-current" : ""}`} />
                          <span>{rawLikeCount}</span>
                        </button>

                        <div className="flex items-center gap-1.5 whitespace-nowrap">
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{rawCommentsCount}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => handleToggleBookmark(e, post.id)}
                        className={`flex items-center gap-1 text-xs font-semibold transition active:scale-95 whitespace-nowrap ${
                          isSaved ? "text-[#86c857]" : "hover:text-zinc-900 dark:hover:text-white"
                        }`}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isSaved ? "fill-current" : ""}`} />
                        <span>{isSaved ? "Saved" : "Save"}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        </main>

        {/* DESKTOP RIGHT SIDEBAR: Live Fraud Watch & Verified Investigators */}
        <aside className="hidden xl:flex flex-col w-72 shrink-0 sticky top-20 space-y-4 select-none">
          {/* Vigilance Impact Card */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 border border-zinc-200/70 dark:border-zinc-800 shadow-xs space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Fraud Protection Impact</span>
            </h4>
            <div className="grid grid-cols-2 gap-2 text-center pt-1">
              <div className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900">
                <div className="text-base font-black text-emerald-600">৳4.8M+</div>
                <div className="text-[10px] text-zinc-500 font-semibold">Fraud Prevented</div>
              </div>
              <div className="p-2.5 rounded-2xl bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700">
                <div className="text-base font-black text-zinc-900 dark:text-white">142+</div>
                <div className="text-[10px] text-zinc-500 font-semibold">Active Alerts</div>
              </div>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed pt-1">
              All published allegations undergo evidence watermark inspection and IMEI cross-checks.
            </p>
          </div>

          {/* Top Verified Investigators (With Verified Rosette for 1k+ Followers) */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 border border-zinc-200/70 dark:border-zinc-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-zinc-400">
                Top Investigators
              </h4>
              <span className="text-[10px] text-[#86c857] font-bold">1k+ followers</span>
            </div>
            <div className="space-y-2.5">
              {[
                {
                  id: "deep_vigilance",
                  name: "Deep Shop Vigilance",
                  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80",
                  followers: 1240,
                  tagline: "Official Trust & Safety Lead",
                  isSeller: false,
                },
                {
                  id: "deep_tech_editor",
                  name: "Tech Desk (Deep Shop)",
                  avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=160&auto=format&fit=crop&q=80",
                  followers: 1080,
                  tagline: "IMEI & Forensics Desk",
                  isSeller: false,
                }
              ].map((inv) => (
                <div 
                  key={inv.id}
                  onClick={() => navigate(`/news-hub/user/${encodeURIComponent(inv.id)}`, {
                    state: {
                      authorName: inv.name,
                      authorAvatar: inv.avatar,
                      isVerified: inv.followers >= 1000,
                      isSeller: inv.isSeller,
                    }
                  })}
                  className="flex items-center justify-between gap-2 p-2 rounded-2xl hover:bg-zinc-50 dark:hover:bg-zinc-800 transition cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={inv.avatar}
                      alt={inv.name}
                      className="w-9 h-9 rounded-full object-cover ring-1 ring-zinc-200 dark:ring-zinc-700 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-zinc-900 dark:text-white truncate">
                          {inv.name}
                        </span>
                        {inv.followers >= 1000 && (
                          <VerifiedBadgeIcon className="w-3.5 h-3.5 shrink-0" />
                        )}
                      </div>
                      <p className="text-[10px] text-zinc-400 truncate">{inv.tagline}</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-zinc-500 dark:text-zinc-400 shrink-0">
                    {inv.followers.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Safety Rule Card */}
          <div className="bg-zinc-50 dark:bg-zinc-900/80 rounded-3xl p-4 border border-zinc-200/70 dark:border-zinc-800 text-xs text-zinc-600 dark:text-zinc-400 space-y-1.5">
            <div className="font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span>Anti-Scam Golden Rule</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Never pay advance to personal bKash/Nagad accounts. Insist on open-box video inspection upon delivery.
            </p>
          </div>
        </aside>
      </div>

      {/* Stealth Admin Edit Modal with Image Management */}
      {editingPost && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 max-w-lg w-full space-y-4 border border-zinc-200 dark:border-zinc-800 shadow-2xl max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-zinc-900 dark:text-white">Edit Report Details & Images</h3>
              <button
                type="button"
                onClick={() => setEditingPost(null)}
                className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-zinc-500 mb-1 block">Title</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#86c857]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-500 mb-1 block">Content</label>
                <textarea
                  rows={4}
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#86c857]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-500 mb-1 block">Tags (comma separated)</label>
                <input
                  type="text"
                  value={editTags}
                  onChange={(e) => setEditTags(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#86c857]"
                />
              </div>

              {/* Admin Image Management */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-zinc-500">Post Evidence Images</label>
                  <label className="text-xs font-bold text-[#86c857] flex items-center gap-1 cursor-pointer hover:underline">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleAdminImageUpload}
                      disabled={isUploadingEditImage}
                    />
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploadingEditImage ? "Watermarking..." : "Add New Image"}</span>
                  </label>
                </div>

                {editImages.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {editImages.map((imgUrl, idx) => (
                      <div key={idx} className="relative rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-700 aspect-video group/img">
                        <img src={imgUrl} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveEditImage(idx)}
                          className="absolute top-1 right-1 w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center shadow-md hover:bg-red-700 cursor-pointer"
                          title="Remove image"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-zinc-400 italic">No images attached.</p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingPost(null)}
                className="px-4 py-2 rounded-full text-xs font-semibold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="px-5 py-2 rounded-full bg-[#86c857] hover:bg-[#78be4a] text-white text-xs font-bold shadow-xs active:scale-95 transition cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation with Home, Scams, Plus, Saved, Profile */}
      <NewsBottomNav
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === "home" || tab === "scams" || tab === "saved") {
            setActiveTab(tab as any);
          }
        }}
      />
    </div>
  );
};
