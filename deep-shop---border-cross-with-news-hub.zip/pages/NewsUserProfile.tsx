import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { 
  ArrowLeft, MoreHorizontal, ShoppingBag, Check, ShieldCheck, 
  AlertTriangle, ThumbsUp, MessageSquare, Share2, 
  X, UserCheck, ShieldAlert, Sparkles, ExternalLink, Plus, LayoutGrid, List
} from "lucide-react";
import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore";
import { db, auth } from "../firebase";
import { NewsPost } from "../types";
import { useNotify } from "../components/Notifications";
import { VerifiedBadgeIcon } from "../components/SellerBadge";

export const NewsUserProfile: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const notify = useNotify();
  const currentUser = auth.currentUser;

  // State passed via navigation (if any)
  const navState = (location.state as any) || {};

  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState(navState.authorName || (userId ? decodeURIComponent(userId) : "Community Member"));
  const [profileAvatar, setProfileAvatar] = useState<string | null>(navState.authorAvatar || null);
  const [profileBio, setProfileBio] = useState<string>(
    navState.bio || "Active Community Reporter & Verified Member at Deep Shop."
  );
  const [isSeller, setIsSeller] = useState<boolean>(navState.isSeller ?? false);
  const [sellerId, setSellerId] = useState<string | null>(navState.sellerId || null);
  const [isAdmin, setIsAdmin] = useState<boolean>(navState.isAdmin ?? false);
  const [isExplicitVerified, setIsExplicitVerified] = useState<boolean>(navState.isVerified ?? false);

  // View Mode: grid (matching the reference image) or list
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Sticky header visibility on scroll
  const [isScrolledPastHero, setIsScrolledPastHero] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  // Follower State (Raw, interactive)
  const targetId = userId || "default_user";
  const [isFollowing, setIsFollowing] = useState<boolean>(() => {
    try {
      return localStorage.getItem(`deepshop_user_following_${targetId}`) === "true";
    } catch {
      return false;
    }
  });

  const [followersCount, setFollowersCount] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(`deepshop_followers_count_${targetId}`);
      if (stored) return parseInt(stored, 10);
    } catch {}
    // Realistic initial raw count
    if (targetId.includes("admin") || targetId.includes("vigilance")) return 1240;
    if (targetId.includes("seller") || navState.isSeller) return 418;
    return 312;
  });

  // User's published posts
  const [userPosts, setUserPosts] = useState<NewsPost[]>([]);

  // 3-dot Menu and Report Modal states
  const [showMenu, setShowMenu] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState("Impersonation / Fake Seller");
  const [reportDetails, setReportDetails] = useState("");
  const [isSubmittingReport, setIsSubmittingReport] = useState(false);

  // Fallback demo posts if user matches demo identities
  const DEMO_POSTS_MAP: Record<string, NewsPost[]> = {
    deep_vigilance: [
      {
        id: "scam_alert_fake_gadget_point",
        title: "🚨 SCAM ALERT: Fake Seller 'Gadget Point' reported for ৳15,000 bKash fraud",
        content: "Customer was promised an authentic border cross phone with 50% advance through personal bKash 01799887766. After payment was transferred, the seller blocked the phone number and WhatsApp immediately.",
        category: "Scam Alert",
        tags: ["#scamalert", "#fraud", "#fakeadvance", "#borderphone"],
        authorId: "deep_vigilance",
        authorName: "Deep Shop Vigilance",
        authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
        isAuthorVerified: true,
        coverImage: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80",
        images: ["https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80"],
        createdAt: Date.now() - 3600 * 1000 * 3,
        publishedAtStr: "3h ago",
        views: 142,
        status: "published",
        isScamReport: true,
        scammerName: "Rakibul Islam (Gadget Point)",
        scammerPhone: "01799887766",
        scammedAmount: 15000,
        totalReactions: 14,
        commentsCount: 5,
        reactions: { like: 14, userReactions: {} },
      },
      {
        id: "demo_post_vigilance_2",
        title: "🛡️ Safe Advance Payment Verification standard for 2026",
        content: "Never pay personal bKash or Nagad. Always verify merchant ID on DEEP SHOP before confirming deliveries.",
        category: "News Report",
        tags: ["#safecommerce", "#tips"],
        authorId: "deep_vigilance",
        authorName: "Deep Shop Vigilance",
        authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
        isAuthorVerified: true,
        coverImage: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80",
        images: ["https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=80"],
        createdAt: Date.now() - 3600 * 1000 * 24,
        publishedAtStr: "1d ago",
        views: 310,
        status: "published",
        totalReactions: 28,
        commentsCount: 9,
      },
      {
        id: "demo_post_vigilance_3",
        title: "📦 Unboxing verification steps before paying courier delivery charge",
        content: "Essential steps to take while the delivery rider is present at your doorstep.",
        category: "News Report",
        tags: ["#delivery", "#courier"],
        authorId: "deep_vigilance",
        authorName: "Deep Shop Vigilance",
        authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
        isAuthorVerified: true,
        coverImage: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
        images: ["https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80"],
        createdAt: Date.now() - 3600 * 1000 * 48,
        publishedAtStr: "2d ago",
        views: 184,
        status: "published",
        totalReactions: 19,
        commentsCount: 3,
      }
    ],
    deep_tech_editor: [
      {
        id: "border_phone_imei_verification_guide",
        title: "📱 Official IMEI Portal Check: How to identify authentic Border Cross Devices",
        content: "Step-by-step instructions for verifying genuine imported border cross phones before transferring any courier advance.",
        category: "News Report",
        tags: ["#borderphone", "#imeicheck"],
        authorId: "deep_tech_editor",
        authorName: "Tech Desk (Deep Shop)",
        authorAvatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=500&auto=format&fit=crop&q=80",
        isAuthorVerified: true,
        coverImage: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&auto=format&fit=crop&q=80",
        images: ["https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&auto=format&fit=crop&q=80"],
        createdAt: Date.now() - 3600 * 1000 * 12,
        publishedAtStr: "12h ago",
        views: 289,
        status: "published",
        totalReactions: 23,
        commentsCount: 8,
      }
    ]
  };

  // Scroll listener to toggle sticky header avatar / follow button (matching Screen 2 of reference image)
  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        setIsScrolledPastHero(rect.bottom < 60);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Fetch user profile and verify store status
  useEffect(() => {
    if (!userId) return;

    const lowerId = userId.toLowerCase();
    const isTargetAdmin = lowerId.includes("admin") || lowerId.includes("vigilance") || lowerId === "deep_tech_editor";
    if (isTargetAdmin) {
      setIsAdmin(true);
    }

    const fetchUserData = async () => {
      try {
        // 1. Check if user document exists in 'users' collection
        let foundStore = false;
        try {
          const uSnap = await getDoc(doc(db, "users", userId));
          if (uSnap.exists()) {
            const uData = uSnap.data();
            if (uData.displayName) setProfileName(uData.displayName);
            if (uData.photoURL) setProfileAvatar(uData.photoURL);
            if (uData.bio) setProfileBio(uData.bio);
            if (uData.isVerified) setIsExplicitVerified(true);
            if (typeof uData.followersCount === "number") setFollowersCount(uData.followersCount);

            // Seller check: has store or role is seller
            if (uData.role === "seller" || uData.isSeller === true || uData.storeName || uData.sellerId) {
              foundStore = true;
              setIsSeller(true);
              setSellerId(uData.sellerId || uData.storeId || userId);
            }
          }
        } catch (e) {
          console.warn("User lookup in Firestore skipped", e);
        }

        // 2. Also check 'stores' collection
        if (!foundStore) {
          try {
            const storeSnap = await getDoc(doc(db, "stores", userId));
            if (storeSnap.exists()) {
              setIsSeller(true);
              setSellerId(userId);
              foundStore = true;
            }
          } catch (e) {}
        }

        // 3. Fallback check for demo sellers/stores
        if (!foundStore) {
          const isKnownSeller = lowerId.includes("seller") || lowerId.includes("gadget") || lowerId.includes("store");
          if (isKnownSeller) {
            setIsSeller(true);
            setSellerId(userId);
          } else if (navState.isSeller) {
            setIsSeller(true);
            setSellerId(navState.sellerId || userId);
          } else {
            setIsSeller(false);
            setSellerId(null);
          }
        }

        // 4. Fetch user's published posts
        const q1 = query(collection(db, "news_posts"), where("authorId", "==", userId));
        const snap1 = await getDocs(q1);
        let posts: NewsPost[] = snap1.docs.map((d) => ({ id: d.id, ...d.data() } as NewsPost));

        if (posts.length === 0) {
          const q2 = query(collection(db, "news_posts"), where("authorName", "==", userId));
          const snap2 = await getDocs(q2);
          posts = snap2.docs.map((d) => ({ id: d.id, ...d.data() } as NewsPost));
        }

        const visiblePosts = posts.filter(p => p.status === "published" || (currentUser && p.authorId === currentUser.uid));

        if (visiblePosts.length === 0 && DEMO_POSTS_MAP[userId]) {
          setUserPosts(DEMO_POSTS_MAP[userId]);
          if (!navState.authorName) {
            setProfileName(DEMO_POSTS_MAP[userId][0].authorName);
            setProfileAvatar(DEMO_POSTS_MAP[userId][0].authorAvatar || null);
          }
        } else {
          setUserPosts(visiblePosts);
          if (visiblePosts.length > 0 && !navState.authorName) {
            setProfileName(visiblePosts[0].authorName);
            setProfileAvatar(visiblePosts[0].authorAvatar || null);
          }
        }
      } catch (err) {
        console.error("Error fetching user profile:", err);
        if (DEMO_POSTS_MAP[userId]) {
          setUserPosts(DEMO_POSTS_MAP[userId]);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId, currentUser?.uid]);

  // Verified Badge Rule: Verified strictly when user has >= 1000 (1K) followers as requested
  const isVerifiedUser = followersCount >= 1000;

  // Handle Follow / Unfollow
  const handleToggleFollow = () => {
    if (!currentUser) {
      notify("Please sign in with your account to follow members", "warning");
      navigate("/signin", { state: { from: location.pathname } });
      return;
    }

    const nextState = !isFollowing;
    const nextCount = nextState ? followersCount + 1 : Math.max(0, followersCount - 1);

    setIsFollowing(nextState);
    setFollowersCount(nextCount);

    try {
      localStorage.setItem(`deepshop_user_following_${targetId}`, String(nextState));
      localStorage.setItem(`deepshop_followers_count_${targetId}`, String(nextCount));
    } catch (e) {
      console.error(e);
    }

    notify(
      nextState ? `You are now following ${profileName}` : `Unfollowed ${profileName}`,
      nextState ? "success" : "info"
    );
  };

  // Submit Profile Report
  const handleSubmitReport = () => {
    setIsSubmittingReport(true);
    setTimeout(() => {
      setIsSubmittingReport(false);
      setShowReportModal(false);
      notify("Report submitted to Deep Shop Trust & Safety team. Thank you!", "success");
    }, 600);
  };

  // Check if viewing own profile
  const isOwnProfile = currentUser?.uid === userId || (currentUser?.displayName && currentUser.displayName === profileName);

  // Large portrait image for the top card (matching reference image)
  const heroImage = profileAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80";

  return (
    <div className="min-h-screen bg-[#fafafa] dark:bg-[#09090b] text-zinc-900 dark:text-zinc-100 font-sans pb-28">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 bg-[#fafafa]/90 dark:bg-[#09090b]/90 backdrop-blur-md px-4 py-3 border-b border-zinc-200/50 dark:border-zinc-800/60 transition-all">
        <div className="max-w-md sm:max-w-xl mx-auto flex items-center justify-between">
          <button
            type="button"
            onClick={() => navigate(-1)}
            aria-label="Go Back"
            className="w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition active:scale-95 cursor-pointer shadow-xs"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          {/* Sticky Header Center Info: Shows compact avatar & name when scrolled past hero (Screen 2 of reference) */}
          <div className={`flex items-center gap-2 transition-all duration-200 ${isScrolledPastHero ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2 pointer-events-none"}`}>
            <img
              src={heroImage}
              alt={profileName}
              className="w-7 h-7 rounded-full object-cover ring-1 ring-zinc-300 dark:ring-zinc-700"
            />
            <div className="flex items-center gap-1 max-w-[140px] truncate">
              <span className="text-xs font-bold truncate text-zinc-900 dark:text-white">
                {profileName}
              </span>
              {isVerifiedUser && <VerifiedBadgeIcon className="w-3.5 h-3.5 shrink-0" />}
            </div>
          </div>

          {/* Right Header Controls: Follow + 3-dots */}
          <div className="flex items-center gap-2">
            {isScrolledPastHero && !isOwnProfile && (
              <button
                type="button"
                onClick={handleToggleFollow}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition active:scale-95 cursor-pointer ${
                  isFollowing
                    ? "bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300"
                    : "bg-zinc-900 text-white dark:bg-white dark:text-zinc-900"
                }`}
              >
                {isFollowing ? "Following" : "+ Follow"}
              </button>
            )}

            <div className="relative">
              <button
                type="button"
                onClick={() => setShowMenu(!showMenu)}
                aria-label="Profile options"
                className="w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition active:scale-95 cursor-pointer shadow-xs"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {showMenu && (
                <div 
                  onClick={(e) => e.stopPropagation()}
                  className="absolute right-0 top-11 z-40 w-48 bg-white dark:bg-zinc-900 rounded-2xl shadow-xl border border-zinc-100 dark:border-zinc-800 py-1.5 text-xs text-zinc-700 dark:text-zinc-200"
                >
                  <button
                    type="button"
                    onClick={() => {
                      setShowMenu(false);
                      setShowReportModal(true);
                    }}
                    className="w-full px-3.5 py-2 text-left hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 dark:text-red-400 flex items-center gap-2.5 font-semibold cursor-pointer"
                  >
                    <ShieldAlert className="w-4 h-4" />
                    <span>Report User Profile</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowMenu(false);
                      navigator.clipboard.writeText(window.location.href);
                      notify("Profile link copied to clipboard!", "success");
                    }}
                    className="w-full px-3.5 py-2 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2.5 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-zinc-400" />
                    <span>Share Profile Link</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Profile Canvas */}
      <main className="max-w-md sm:max-w-xl mx-auto px-4 pt-4 space-y-6">
        {/* HERO SECTION - Style matching uploaded reference image IMG_4530.webp */}
        <div ref={heroRef} className="space-y-4">
          {/* 1. Large Top Portrait Card (rounded-[28px] sm:rounded-[36px]) */}
          <div className="w-full aspect-square rounded-[28px] sm:rounded-[36px] overflow-hidden bg-zinc-900 shadow-md relative group select-none">
            <img
              src={heroImage}
              alt={profileName}
              onError={(e) => {
                // Fallback to high-res aesthetic portrait if url fails
                (e.currentTarget as HTMLImageElement).src = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80";
              }}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
            />
            {/* Subtle bottom gradient overlay for contrast */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" />
          </div>

          {/* 2. User Info Section (Left-aligned, pristine typography) */}
          <div className="space-y-2 pt-1 px-1">
            {/* Name + Verified Rosette Badge */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">
                {profileName}
              </h1>
              {isVerifiedUser && (
                <VerifiedBadgeIcon className="w-5 h-5 shrink-0" />
              )}
            </div>

            {/* Bio line */}
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed font-normal">
              {profileBio}
            </p>

            {/* Stats: 312 Followers  10 Posts */}
            <div className="flex items-center gap-4 text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 pt-1 font-normal">
              <p>
                <strong className="font-bold text-zinc-900 dark:text-white mr-1">
                  {followersCount.toLocaleString()}
                </strong>
                Followers
              </p>
              <p>
                <strong className="font-bold text-zinc-900 dark:text-white mr-1">
                  {userPosts.length}
                </strong>
                Posts
              </p>
            </div>
          </div>

          {/* 3. Action Buttons */}
          <div className="space-y-2 px-1 pt-1">
            {/* Follow / Edit Profile Button */}
            {isOwnProfile ? (
              <button
                type="button"
                onClick={() => navigate("/profile")}
                className="w-full py-3 sm:py-3.5 rounded-full bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-900 dark:text-white text-xs sm:text-sm font-bold transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Edit Profile</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleToggleFollow}
                className={`w-full py-3 sm:py-3.5 rounded-full text-xs sm:text-sm font-bold transition active:scale-98 cursor-pointer flex items-center justify-center gap-2 ${
                  isFollowing
                    ? "bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200"
                    : "bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-900 dark:text-white"
                }`}
              >
                {isFollowing ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span>Following</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Follow</span>
                  </>
                )}
              </button>
            )}

            {/* VISIT STORE BUTTON: Rendered ONLY if the user has an active store / is a seller! */}
            {isSeller && (
              <button
                type="button"
                onClick={() => navigate(`/store/${sellerId || "deep_shop"}`)}
                className="w-full py-3 sm:py-3.5 rounded-full bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-100 text-white dark:text-zinc-900 text-xs sm:text-sm font-bold shadow-sm transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Visit Store</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60" />
              </button>
            )}
          </div>
        </div>

        {/* SECTION: My Posts (Matches Reference 3-column Grid) */}
        <section className="pt-4 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-base sm:text-lg font-bold text-zinc-900 dark:text-white tracking-tight">
              My Posts
            </h2>
            {/* View Mode Toggle */}
            <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setViewMode("grid")}
                aria-label="Grid view"
                className={`p-1.5 rounded-lg transition cursor-pointer ${
                  viewMode === "grid" 
                    ? "bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white shadow-xs" 
                    : "text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode("list")}
                aria-label="List view"
                className={`p-1.5 rounded-lg transition cursor-pointer ${
                  viewMode === "list" 
                    ? "bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white shadow-xs" 
                    : "text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                }`}
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <div key={n} className="aspect-square rounded-[20px] bg-zinc-200 dark:bg-zinc-800 animate-pulse" />
              ))}
            </div>
          ) : userPosts.length === 0 ? (
            <div className="bg-white dark:bg-zinc-900 rounded-[28px] p-8 border border-zinc-200/60 dark:border-zinc-800 text-center space-y-2">
              <ShieldCheck className="w-8 h-8 text-zinc-300 dark:text-zinc-700 mx-auto" />
              <p className="text-sm font-bold text-zinc-700 dark:text-zinc-300">
                No Posts Published Yet
              </p>
              <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                This community member has not shared any public investigations or updates yet.
              </p>
            </div>
          ) : viewMode === "grid" ? (
            /* 3-Column Square Image Grid matching reference image IMG_4530.webp */
            <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
              {userPosts.map((post) => {
                const cover = post.coverImage || post.images?.[0];
                return (
                  <div
                    key={post.id}
                    onClick={() => navigate(`/news-hub/${post.id}`)}
                    className="aspect-square rounded-[18px] sm:rounded-[22px] overflow-hidden bg-zinc-100 dark:bg-zinc-800 shadow-xs relative cursor-pointer group select-none border border-zinc-200/40 dark:border-zinc-800/40"
                  >
                    {cover ? (
                      <img
                        src={cover}
                        alt={post.title}
                        loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-zinc-100 to-zinc-200 dark:from-zinc-800 dark:to-zinc-900 p-2.5 flex flex-col justify-between">
                        <span className="text-[10px] font-bold text-zinc-500 line-clamp-3">
                          {post.title}
                        </span>
                        <span className="text-[9px] text-zinc-400 font-mono">
                          {post.category || "Report"}
                        </span>
                      </div>
                    )}
                    {/* Subtle hover overlay */}
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors pointer-events-none" />
                  </div>
                );
              })}
            </div>
          ) : (
            /* Detailed List View */
            <div className="space-y-3">
              {userPosts.map((post) => {
                const cover = post.coverImage || post.images?.[0];
                const rawLikes = post.reactions?.like ?? post.totalReactions ?? 0;
                const rawComments = post.commentsCount ?? 0;

                return (
                  <article
                    key={post.id}
                    onClick={() => navigate(`/news-hub/${post.id}`)}
                    className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/70 dark:border-zinc-800 shadow-xs hover:shadow-sm transition cursor-pointer space-y-2.5"
                  >
                    <div className="flex items-center justify-between text-[11px] text-zinc-400">
                      <span className={`px-2 py-0.5 rounded-full font-bold uppercase tracking-wider text-[10px] ${
                        post.category === "Scam Alert" || post.isScamReport
                          ? "bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-400"
                          : "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400"
                      }`}>
                        {post.category || "Report"}
                      </span>
                      <span>{post.publishedAtStr || "Recently"}</span>
                    </div>

                    <h3 className="text-sm font-bold text-zinc-900 dark:text-white line-clamp-2">
                      {post.title}
                    </h3>

                    {cover && (
                      <div className="w-full h-36 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-800">
                        <img src={cover} alt={post.title} className="w-full h-full object-cover" />
                      </div>
                    )}

                    <div className="flex items-center justify-between text-xs text-zinc-400 pt-1">
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <ThumbsUp className="w-3.5 h-3.5" />
                          <span>{rawLikes}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{rawComments}</span>
                        </span>
                      </div>
                      <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
                        Read full story →
                      </span>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </main>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 w-full max-w-sm rounded-[28px] p-6 space-y-4 shadow-2xl border border-zinc-200 dark:border-zinc-800 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                Report User Profile
              </h3>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-500 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-500 font-medium mb-1">Reason for report</label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                >
                  <option value="Impersonation / Fake Seller">Impersonation / Fake Seller</option>
                  <option value="Fraudulent Scam Reports">Fraudulent Scam Reports</option>
                  <option value="Abusive Language / Harassment">Abusive Language / Harassment</option>
                  <option value="Spam / Advertisements">Spam / Advertisements</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-500 font-medium mb-1">Additional Details</label>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Provide context or links..."
                  className="w-full p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="px-4 py-2 rounded-full text-xs font-semibold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmitReport}
                disabled={isSubmittingReport}
                className="px-5 py-2 rounded-full bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-xs active:scale-95 transition cursor-pointer"
              >
                {isSubmittingReport ? "Submitting..." : "Submit Report"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
