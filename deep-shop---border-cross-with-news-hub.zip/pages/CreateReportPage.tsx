import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ShieldAlert, Upload, X, AlertTriangle, Image as ImageIcon, Send, Lock } from "lucide-react";
import { auth, db } from "../firebase";
import { collection, addDoc, doc, getDoc } from "firebase/firestore";
import { useNotify } from "../components/Notifications";
import { applyWatermarkToImage } from "@/src/lib/watermark";
import { checkNeedsAdminReview } from "@/src/lib/sensitiveReview";
import { uploadToImgbb } from "../services/imgbb";
import { NewsCategory, NewsPost } from "../types";

export const CreateReportPage: React.FC = () => {
  const navigate = useNavigate();
  const notify = useNotify();
  const currentUser = auth.currentUser;

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<NewsCategory>("Scam Alert");
  const [tags, setTags] = useState("#scamalert #fraud #warning");

  // Scam details
  const [isScam, setIsScam] = useState(true);
  const [scammerName, setScammerName] = useState("");
  const [scammerPhone, setScammerPhone] = useState("");
  const [scammerPaymentInfo, setScammerPaymentInfo] = useState("");
  const [scammedAmount, setScammedAmount] = useState<number | "">("");
  const [scammerSocialLink, setScammerSocialLink] = useState("");

  // Multiple Watermarked Images
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [isProcessingPhotos, setIsProcessingPhotos] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handlePhotosChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessingPhotos(true);
    notify("Applying 'Revealed On DEEP SHOP' repeating watermark...", "info");

    try {
      const processed: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const { dataUrl, file: stampedFile } = await applyWatermarkToImage(file, {
          watermarkText: "Revealed On DEEP SHOP",
          subText: "OFFICIAL SCAM ALERT • VERIFIED REPORT",
          opacity: 0.38,
        });

        try {
          const uploadedUrl = await uploadToImgbb(stampedFile);
          processed.push(uploadedUrl || dataUrl);
        } catch {
          processed.push(dataUrl);
        }
      }

      setUploadedImages((prev) => [...prev, ...processed]);
      notify(`${processed.length} photo(s) watermarked and attached!`, "success");
    } catch (err) {
      console.error("Watermark processing error:", err);
      notify("Failed to process some images", "error");
    } finally {
      setIsProcessingPhotos(false);
    }
  };

  const handleRemoveImage = (index: number) => {
    setUploadedImages((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      notify("Please sign in or create an account to submit a report!", "error");
      navigate("/signin");
      return;
    }

    if (!title.trim()) {
      notify("Please enter a headline", "error");
      return;
    }

    if (!content.trim()) {
      notify("Please provide the full story and details", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      const needsReview = checkNeedsAdminReview(
        title,
        content,
        scammerName,
        scammerPhone
      );

      let authorName = currentUser.displayName || currentUser.email?.split("@")[0] || "Deep Citizen";
      let authorAvatar = currentUser.photoURL || "";
      try {
        const uSnap = await getDoc(doc(db, "users", currentUser.uid));
        if (uSnap.exists()) {
          const uData = uSnap.data();
          if (uData.displayName) authorName = uData.displayName;
          if (uData.photoURL) authorAvatar = uData.photoURL;
        }
      } catch (err) {
        // fallback
      }

      const coverImg = uploadedImages[0] || "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=1200";

      const postPayload: any = {
        title: title.trim(),
        content: content.trim(),
        category,
        tags: tags.split(" ").filter((t) => t.trim().length > 0),
        sourceName: isScam ? "Community Investigation" : "Community Post",
        sourceAvatar: authorAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80",
        isVerifiedSource: false,
        authorId: currentUser.uid,
        authorName,
        authorEmail: currentUser.email || "",
        authorAvatar,
        isAuthorVerified: true,
        coverImage: coverImg,
        images: uploadedImages.length > 0 ? uploadedImages : [coverImg],
        watermarked: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        publishedAtStr: `Posted ${new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true })}`,
        views: 1,
        status: needsReview ? "pending_admin_review" : "published",
        sensitiveReviewNeeded: needsReview,

        // Scammer details
        isScamReport: isScam,
        scammerName: scammerName.trim() || undefined,
        scammerPhone: scammerPhone.trim() || undefined,
        scammerPaymentInfo: scammerPaymentInfo.trim() || undefined,
        scammedAmount: Number(scammedAmount) || undefined,
        scammerSocialLink: scammerSocialLink.trim() || undefined,
        scamVerdict: "scammer",

        scamVotes: {
          scammerCount: 1,
          suspiciousCount: 0,
          innocentCount: 0,
          userVotes: {
            [currentUser.uid]: "scammer",
          },
        },

        reactions: {
          like: 1,
          love: 0,
          alert: 1,
          userReactions: {
            [currentUser.uid]: "like",
          },
        },
        totalReactions: 1,
        commentsCount: 0,
      };

      const docRef = await addDoc(collection(db, "news_posts"), postPayload);
      notify("Report published successfully!", "success");
      navigate(`/news-hub/${docRef.id}`);
    } catch (err) {
      console.error("Create post error:", err);
      notify("Failed to publish report. Please try again.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8faf9] dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 pb-20">
      {/* Top Header */}
      <div className="sticky top-0 z-40 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 transition cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-sm sm:text-base font-extrabold text-zinc-900 dark:text-white leading-tight">
              Report Scam / Expose Fraud
            </h1>
            <p className="text-[10px] text-zinc-500 font-medium">
              Auto-stamped with <span className="text-red-600 font-bold">Revealed On DEEP SHOP</span>
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          disabled={isSubmitting || isProcessingPhotos}
          className="px-4 py-2 rounded-full bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs shadow-md transition active:scale-95 disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
        >
          <Send className="w-3.5 h-3.5" />
          <span>{isSubmitting ? "Publishing..." : "Publish"}</span>
        </button>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Category Pill Switcher */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setIsScam(true);
              setCategory("Scam Alert");
            }}
            className={`px-4 py-2 rounded-full text-xs font-bold transition cursor-pointer ${
              isScam
                ? "bg-red-600 text-white shadow-md"
                : "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300"
            }`}
          >
            🚨 Scam Report / প্রতারণা
          </button>
          <button
            type="button"
            onClick={() => {
              setIsScam(false);
              setCategory("All News");
            }}
            className={`px-4 py-2 rounded-full text-xs font-bold transition cursor-pointer ${
              !isScam
                ? "bg-black dark:bg-white text-white dark:text-black shadow-md"
                : "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300"
            }`}
          >
            💬 General Discussion / News
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Headline Title */}
          <div className="p-4 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-xs space-y-1.5">
            <label className="block text-xs font-extrabold text-zinc-700 dark:text-zinc-300">
              Headline Title *
            </label>
            <input
              type="text"
              required
              placeholder={isScam ? "e.g. Scammer took ৳15,000 for iPhone 15 and blocked number" : "Discussion Topic or Title"}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 text-sm font-bold bg-transparent outline-none border-b border-zinc-200 dark:border-zinc-800 focus:border-red-500"
            />
          </div>

          {/* Hashtags */}
          <div className="p-4 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-xs space-y-1.5">
            <label className="block text-xs font-extrabold text-zinc-700 dark:text-zinc-300">
              Topic Hashtags
            </label>
            <input
              type="text"
              placeholder="#scamalert #bkashfraud #warning #fakephone"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full px-3 py-1.5 text-xs font-medium text-blue-600 dark:text-blue-400 bg-transparent outline-none font-mono"
            />
          </div>

          {/* Scammer Details Card (if scam) */}
          {isScam && (
            <div className="p-5 rounded-3xl bg-red-50/60 dark:bg-red-950/20 border border-red-200 dark:border-red-900/50 space-y-3.5 shadow-xs">
              <div className="flex items-center gap-1.5 text-xs font-black text-red-700 dark:text-red-400">
                <AlertTriangle className="w-4 h-4" />
                <span>Fraudster Evidence Profile</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                    Scammer Name / Shop Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Shakil / Tech Mart BD"
                    value={scammerName}
                    onChange={(e) => setScammerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 font-semibold outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                    Scammer Contact / Phone Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 017XXXXXXXX"
                    value={scammerPhone}
                    onChange={(e) => setScammerPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 font-mono font-bold outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                    bKash / Nagad / Bank Account
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 019XXXXXXXX (Personal)"
                    value={scammerPaymentInfo}
                    onChange={(e) => setScammerPaymentInfo(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 font-semibold outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                    Amount Scammed (৳)
                  </label>
                  <input
                    type="number"
                    placeholder="৳ 0.00"
                    value={scammedAmount}
                    onChange={(e) => setScammedAmount(e.target.value ? Number(e.target.value) : "")}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 font-black text-red-600 outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Photo Upload with Guaranteed Repeating Watermark */}
          <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-xs font-extrabold text-zinc-900 dark:text-white">
                  Evidence Photos (Auto-Watermarked)
                </label>
                <p className="text-[10px] text-zinc-400">
                  Select one or multiple screenshots. They will automatically be stamped with "Revealed On DEEP SHOP" all over!
                </p>
              </div>
            </div>

            {/* Upload Area */}
            <label className="w-full flex flex-col items-center justify-center gap-2 p-6 rounded-2xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 hover:border-red-500 bg-zinc-50 dark:bg-zinc-850 cursor-pointer transition">
              <Upload className="w-6 h-6 text-red-600" />
              <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300">
                {isProcessingPhotos ? "Watermarking Images..." : "+ Click to Upload Evidence Photos"}
              </span>
              <span className="text-[10px] text-zinc-400">PNG, JPG, WebP supported</span>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handlePhotosChange}
                disabled={isProcessingPhotos}
                className="hidden"
              />
            </label>

            {/* Uploaded Photos Preview List */}
            {uploadedImages.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                {uploadedImages.map((imgUrl, idx) => (
                  <div
                    key={idx}
                    className="relative rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-700 aspect-video bg-zinc-950 group"
                  >
                    <img src={imgUrl} alt="Evidence" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center pointer-events-none">
                      <span className="text-[8px] font-black text-white px-1 py-0.5 rounded bg-black/60 text-center">
                        Revealed On DEEP SHOP
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center text-xs shadow-md transition hover:scale-110"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Narrative Content */}
          <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-xs space-y-2">
            <label className="block text-xs font-extrabold text-zinc-900 dark:text-white">
              Full Narrative & Evidence Story *
            </label>
            <textarea
              required
              rows={6}
              placeholder="Describe the entire incident step-by-step. Include date, communication platform, false promises made, transaction IDs, etc..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full p-3 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-850 text-xs sm:text-sm font-medium outline-none focus:border-red-500 leading-relaxed resize-y"
            />
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting || isProcessingPhotos}
              className="w-full py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-black text-sm shadow-xl transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-5 h-5" />
              <span>{isSubmitting ? "Publishing Investigation..." : "Publish to News Hub"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
