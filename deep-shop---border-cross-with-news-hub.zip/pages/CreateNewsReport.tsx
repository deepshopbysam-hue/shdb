import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  ArrowLeft, AlertTriangle, ShieldCheck, Upload, X, Check, 
  Image as ImageIcon, Info, Lock, Send, Sparkles 
} from "lucide-react";
import { collection, addDoc } from "firebase/firestore";
import { db, auth } from "../firebase";
import { useNotify } from "../components/Notifications";
import { applyWatermarkToImage } from "@/src/lib/watermark";
import { checkNeedsAdminReview } from "@/src/lib/sensitiveReview";
import { uploadToImgbb } from "../services/imgbb";

export const CreateNewsReport: React.FC = () => {
  const navigate = useNavigate();
  const notify = useNotify();
  const currentUser = auth.currentUser;

  const [postType, setPostType] = useState<"scam" | "general">("scam");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("Scam Alert");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>(["#scamalert", "#fraud"]);

  // Scam specific fields
  const [scammerName, setScammerName] = useState("");
  const [scammerPhone, setScammerPhone] = useState("");
  const [scammerPaymentInfo, setScammerPaymentInfo] = useState("");
  const [scammedAmount, setScammedAmount] = useState("");
  const [scammerLink, setScammerLink] = useState("");

  // Uploaded watermarked images
  const [images, setImages] = useState<string[]>([]);
  const [isWatermarking, setIsWatermarking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Require account to post
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#fcfcfd] dark:bg-zinc-950 text-zinc-900 dark:text-white flex flex-col justify-center items-center p-6 text-center">
        <div className="max-w-md w-full p-8 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xl space-y-6">
          <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-950/60 text-red-600 flex items-center justify-center mx-auto">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-black">Account Required</h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              To submit verified scam evidence or publish community news, you need an active Deep Shop account.
            </p>
          </div>
          <div className="space-y-3 pt-2">
            <button
              onClick={() => navigate("/signin")}
              className="w-full py-3 rounded-2xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-bold text-sm shadow-md hover:opacity-90 transition cursor-pointer"
            >
              Sign In to Your Account
            </button>
            <button
              onClick={() => navigate("/news-hub")}
              className="w-full py-2.5 rounded-2xl text-xs font-bold text-zinc-500 hover:text-zinc-800 dark:hover:text-white transition cursor-pointer"
            >
              Back to News Hub
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Handle Photo selection and apply auto-watermark
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsWatermarking(true);
    notify("Applying 'Revealed On DEEP SHOP' watermark...", "info");

    try {
      const newWatermarkedUrls: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        // Apply permanent watermark on canvas
        const { blob, dataUrl } = await applyWatermarkToImage(file, {
          watermarkText: "Revealed On DEEP SHOP",
          subText: "DEEP SHOP VERIFIED EVIDENCE",
          opacity: 0.25,
        });

        // Upload permanently watermarked blob to Imgbb or fallback to dataUrl
        try {
          const watermarkedFile = new File([blob], `scam-evidence-${Date.now()}-${i}.jpg`, {
            type: "image/jpeg",
          });
          const uploadedUrl = await uploadToImgbb(watermarkedFile);
          newWatermarkedUrls.push(uploadedUrl || dataUrl);
        } catch {
          newWatermarkedUrls.push(dataUrl);
        }
      }

      setImages((prev) => [...prev, ...newWatermarkedUrls]);
      notify("Watermark applied successfully!", "success");
    } catch (err) {
      console.error(err);
      notify("Failed to watermark image", "error");
    } finally {
      setIsWatermarking(false);
      e.target.value = "";
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    setImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleAddTag = (tagToAdd: string) => {
    const cleaned = tagToAdd.startsWith("#") ? tagToAdd.trim() : `#${tagToAdd.trim()}`;
    if (cleaned.length > 1 && !tags.includes(cleaned)) {
      setTags([...tags, cleaned]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      notify("Please enter a title", "warning");
      return;
    }
    if (!content.trim()) {
      notify("Please describe the incident or news details", "warning");
      return;
    }

    setIsSubmitting(true);

    try {
      // Check for sensitive shadow moderation
      const combinedText = `${title} ${content} ${scammerName} ${scammerPaymentInfo}`;
      const needsReview = checkNeedsAdminReview(combinedText);
      const postStatus = needsReview ? "pending_admin_review" : "published";

      const newPostData = {
        title: title.trim(),
        content: content.trim(),
        category: postType === "scam" ? "Scam Alert" : category,
        tags: tags.length > 0 ? tags : ["#scamalert", "#fraud"],
        authorId: currentUser.uid,
        authorName: currentUser.displayName || currentUser.email?.split("@")[0] || "Deep Shop Reporter",
        authorAvatar: currentUser.photoURL || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120",
        isAuthorVerified: true,
        sourceName: "Deep Shop Alert",
        sourceAvatar: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=120",
        isVerifiedSource: true,
        coverImage: images[0] || "",
        images: images,
        createdAt: Date.now(),
        publishedAtStr: "Just now",
        views: 1,
        status: postStatus,
        isScamReport: postType === "scam",
        scammerName: scammerName.trim() || undefined,
        scammerPhone: scammerPhone.trim() || undefined,
        scammerPaymentInfo: scammerPaymentInfo.trim() || undefined,
        scammedAmount: scammedAmount ? Number(scammedAmount) : undefined,
        scamVerdict: "suspicious",
        scamVotes: {
          scammerCount: 1,
          suspiciousCount: 0,
          innocentCount: 0,
          userVotes: {
            [currentUser.uid]: "scammer",
          },
        },
        totalReactions: 1,
        commentsCount: 0,
        reactions: {
          like: 1,
          alert: 1,
          userReactions: {
            [currentUser.uid]: "like",
          },
        },
      };

      const docRef = await addDoc(collection(db, "news_posts"), newPostData);

      // Show instant positive feedback to the author as requested
      notify("Report published successfully!", "success");
      navigate(`/news-hub/${docRef.id}`);
    } catch (err) {
      console.error(err);
      notify("Failed to publish report. Please try again.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fcfcfd] dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 pb-20">
      {/* Top Header */}
      <div className="sticky top-0 z-40 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md px-4 py-3 border-b border-zinc-200/80 dark:border-zinc-800">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <button
            type="button"
            onClick={() => navigate("/news-hub")}
            className="flex items-center gap-1.5 text-xs font-bold text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          <h1 className="text-sm font-black truncate text-zinc-900 dark:text-white">
            Publish on News Hub
          </h1>

          <button
            type="button"
            onClick={() => navigate("/news-hub")}
            className="text-xs font-bold text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
          >
            Cancel
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Post Type Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-zinc-100 dark:bg-zinc-850 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setPostType("scam");
              setCategory("Scam Alert");
            }}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-xl transition cursor-pointer ${
              postType === "scam"
                ? "bg-red-600 text-white shadow-sm"
                : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Expose Scam / Fraud</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setPostType("general");
              setCategory("Tech");
            }}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-xl transition cursor-pointer ${
              postType === "general"
                ? "bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs"
                : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>General Discussion</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Title (Single line discipline with clear guidance) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300">
              Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                postType === "scam"
                  ? "e.g. Fake seller 'Gadget Point' reported for ৳15,000 bKash fraud"
                  : "e.g. What is your go-to skincare routine for summer?"
              }
              className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          {/* Scam Details Section */}
          {postType === "scam" && (
            <div className="p-4 rounded-2xl bg-red-50/60 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 space-y-3.5">
              <div className="flex items-center gap-2 text-xs font-black text-red-600 dark:text-red-400 uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4" />
                <span>Scammer Identity Information</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 dark:text-zinc-400 mb-1">
                    Scammer Name / Fake Page
                  </label>
                  <input
                    type="text"
                    value={scammerName}
                    onChange={(e) => setScammerName(e.target.value)}
                    placeholder="e.g. Rakibul Islam / Gadget Point BD"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs focus:outline-none focus:ring-1 focus:ring-red-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 dark:text-zinc-400 mb-1">
                    Scammer Contact / Phone Number
                  </label>
                  <input
                    type="text"
                    value={scammerPhone}
                    onChange={(e) => setScammerPhone(e.target.value)}
                    placeholder="e.g. 01799887766"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-red-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 dark:text-zinc-400 mb-1">
                    Payment Channel Used
                  </label>
                  <input
                    type="text"
                    value={scammerPaymentInfo}
                    onChange={(e) => setScammerPaymentInfo(e.target.value)}
                    placeholder="e.g. bKash Personal 01799887766 / Nagad"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs focus:outline-none focus:ring-1 focus:ring-red-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 dark:text-zinc-400 mb-1">
                    Scammed Amount (৳ BDT)
                  </label>
                  <input
                    type="number"
                    value={scammedAmount}
                    onChange={(e) => setScammedAmount(e.target.value)}
                    placeholder="e.g. 15000"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-red-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Description / Evidence Text */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300">
              Detailed Evidence & Story <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={5}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Explain how the incident took place, what payment was sent, and why other customers should be vigilant..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs sm:text-sm font-normal focus:outline-none focus:ring-2 focus:ring-red-500 resize-none leading-relaxed"
            />
          </div>

          {/* Multi-Photo Upload with Automatic Watermark */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-red-500" />
                <span>Evidence Photos & Screenshots</span>
              </label>
              <span className="text-[10px] text-zinc-400 font-bold">
                Auto-watermarked with "Revealed On DEEP SHOP"
              </span>
            </div>

            {/* Photo Previews */}
            {images.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {images.map((img, idx) => (
                  <div key={idx} className="relative aspect-video rounded-xl overflow-hidden bg-zinc-900 border border-zinc-200 dark:border-zinc-800 group">
                    <img src={img} alt="Evidence" className="w-full h-full object-cover" />
                    {/* Watermark Tag */}
                    <div className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded-md bg-black/70 text-[9px] font-black text-white pointer-events-none">
                      Revealed On DEEP SHOP
                    </div>
                    {/* Remove Button */}
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center shadow-md hover:bg-red-700 transition cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Upload Button */}
            <label className="flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-850 cursor-pointer transition">
              <Upload className="w-6 h-6 text-zinc-400 mb-2" />
              <span className="text-xs font-bold text-zinc-700 dark:text-zinc-200">
                {isWatermarking ? "Applying Watermark..." : "Click to Upload Photos / Screenshots"}
              </span>
              <span className="text-[10px] text-zinc-400 mt-0.5">
                PNG, JPG or WEBP (Automatically watermarked with Deep Shop signature)
              </span>
              <input
                type="file"
                multiple
                accept="image/*"
                disabled={isWatermarking}
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Hashtags */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300">
              Tags / Keywords
            </label>
            <div className="flex flex-wrap items-center gap-1.5">
              {tags.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                >
                  <span>{t}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(t)}
                    className="text-zinc-400 hover:text-zinc-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddTag(tagInput);
                  }
                }}
                placeholder="Type tag (e.g. #fakeadvance) and press Enter"
                className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs focus:outline-none focus:ring-1 focus:ring-red-500"
              />
              <button
                type="button"
                onClick={() => handleAddTag(tagInput)}
                className="px-3.5 py-2 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-xs font-bold hover:bg-zinc-300 transition"
              >
                Add
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={isSubmitting || isWatermarking}
              className="w-full py-3.5 rounded-2xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm shadow-lg flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer"
            >
              {isSubmitting ? (
                <span>Publishing Evidence...</span>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Publish Report & Alert Community</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
