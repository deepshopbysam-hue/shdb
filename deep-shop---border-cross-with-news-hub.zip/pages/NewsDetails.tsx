import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { 
  ArrowLeft, Plus, MoreHorizontal, ThumbsUp, ThumbsDown, 
  MessageSquare, Bookmark, Send, Image as ImageIcon, X, 
  Share2, Trash2, Edit3, Check, CornerDownRight, AlertTriangle, Upload
} from "lucide-react";
import { 
  doc, getDoc, updateDoc, collection, addDoc, onSnapshot, 
  query, orderBy, deleteDoc, increment, arrayUnion, arrayRemove 
} from "firebase/firestore";
import { db, auth } from "../firebase";
import { NewsComment, NewsPost } from "../types";
import { WatermarkedImageViewer } from "../components/news/WatermarkedImageViewer";
import { ScamVotingCard, VoteChoice } from "../components/news/ScamVotingCard";
import { useNotify } from "../components/Notifications";
import { applyWatermarkToImage } from "@/src/lib/watermark";
import { checkNeedsAdminReview } from "@/src/lib/sensitiveReview";
import { uploadToImgbb } from "../services/imgbb";
import { VerifiedBadgeIcon } from "../components/SellerBadge";

// Authentic Tech / Scam Alert Fallback (No beauty/skincare)
const FALLBACK_POST: NewsPost = {
  id: "scam_alert_fake_gadget_point",
  title: "🚨 SCAM ALERT: Fake Seller 'Gadget Point' reported for ৳15,000 bKash fraud",
  content: "User ordered an authentic border cross phone with 50% advance through personal bKash number 01799887766. After payment was confirmed, the customer was blocked immediately across both WhatsApp and phone calls.\n\nPlease exercise extreme caution and never transfer advance money to personal unverified accounts. Always verify IMEI numbers and demand courier condition with unboxing video verification.",
  category: "Scam Alert",
  tags: ["#scamalert", "#fraud", "#fakeadvance", "#borderphone"],
  authorId: "deep_vigilance",
  authorName: "Deep Shop Vigilance",
  authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80",
  isAuthorVerified: true,
  coverImage: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80",
  images: ["https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80"],
  createdAt: Date.now() - 3600 * 1000 * 3,
  publishedAtStr: "3h ago",
  views: 142,
  status: "published",
  isScamReport: true,
  scammerName: "Rakibul Islam (Gadget Point)",
  scammerPhone: "01799887766",
  scammedAmount: 15000,
  totalReactions: 14,
  commentsCount: 2,
  reactions: { like: 14, userReactions: {} },
};

// Raw initial demo comments
const INITIAL_DEMO_COMMENTS: NewsComment[] = [
  {
    id: "comment_1",
    postId: "scam_alert_fake_gadget_point",
    authorId: "farhan_buyer",
    authorName: "Farhan Ahmed",
    authorAvatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=160&auto=format&fit=crop&q=80",
    isVerified: true,
    content: "এই একই নম্বর থেকে ৩ দিন আগেও মিরপুরের এক ভাইয়ের কাছ থেকে ৩০০০ টাকা অ্যাডভান্স নিয়ে ব্লক করেছিল। প্রশাসন ও সাইবার ক্রাইমে অবিলম্বে এই নম্বরের বিরুদ্ধে রিপোর্ট করা উচিত।",
    createdAt: Date.now() - 3600 * 1000 * 2,
    status: "published",
    likesCount: 6,
    likedBy: [],
  },
  {
    id: "comment_2",
    postId: "scam_alert_fake_gadget_point",
    authorId: "shanto_tech",
    authorName: "Shanto Tech",
    authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80",
    isVerified: true,
    content: "সবাইকে অনুরোধ—ডিপ শপ ছাড়া বাইরের কোনো ব্যক্তিগত ফেসবুক পেইজে ৫০০ টাকার বেশি অ্যাডভান্স করবেন না। সবসময় ওপেন বক্স কন্ডিশনে পার্সেল রিসিভ করবেন।",
    createdAt: Date.now() - 3600 * 1000,
    status: "published",
    likesCount: 4,
    likedBy: [],
  }
];

export const NewsDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const notify = useNotify();
  const currentUser = auth.currentUser;
  const commentsEndRef = useRef<HTMLDivElement>(null);

  const [post, setPost] = useState<NewsPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFollowingTopic, setIsFollowingTopic] = useState(false);
  const [isFollowingAuthor, setIsFollowingAuthor] = useState(false);
  const [isSaved, setIsSaved] = useState(() => {
    try {
      const stored = localStorage.getItem("deepshop_saved_news_ids");
      const map = stored ? JSON.parse(stored) : {};
      return !!map[id || ""];
    } catch {
      return false;
    }
  });

  // Strictly Raw Counts
  const [userReaction, setUserReaction] = useState<"like" | "dislike" | null>(null);
  const [likeCount, setLikeCount] = useState<number>(0);
  const [dislikeCount, setDislikeCount] = useState<number>(0);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  // Stealth Admin Post Edit State (Content + Images)
  const [isEditingPost, setIsEditingPost] = useState(false);
  const [editPostTitle, setEditPostTitle] = useState("");
  const [editPostContent, setEditPostContent] = useState("");
  const [editPostImages, setEditPostImages] = useState<string[]>([]);
  const [isUploadingPostImage, setIsUploadingPostImage] = useState(false);

  // Comments & Replies state
  const [comments, setComments] = useState<NewsComment[]>([]);
  const [newCommentText, setNewCommentText] = useState("");
  const [commentPhoto, setCommentPhoto] = useState<string>("");
  const [isWatermarkingCommentPhoto, setIsWatermarkingCommentPhoto] = useState(false);
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [replyingTo, setReplyingTo] = useState<NewsComment | null>(null);

  // Stealth Comment Edit State (Content + Image)
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editCommentText, setEditCommentText] = useState("");
  const [editCommentImage, setEditCommentImage] = useState<string>("");
  const [activeMenuCommentId, setActiveMenuCommentId] = useState<string | null>(null);

  const isAdmin = currentUser?.email === "claimfaf@gmail.com" || 
                  currentUser?.email === "admin@deep.shop" || 
                  currentUser?.email === "deepshop@gmail.com" ||
                  currentUser?.email === "zixpower74@gmail.com";

  // Fetch Post Details & initialize real raw reactions
  useEffect(() => {
    if (!id) return;

    if (id === "scam_alert_fake_gadget_point" || id === "test_demo_1") {
      setPost(FALLBACK_POST);
      setLikeCount(FALLBACK_POST.reactions?.like || 14);
      setComments(INITIAL_DEMO_COMMENTS);
      setLoading(false);
      return;
    }

    const unsubPost = onSnapshot(doc(db, "news_posts", id), (snap) => {
      if (snap.exists()) {
        const data = { id: snap.id, ...snap.data() } as NewsPost;
        setPost(data);
        setLikeCount(data.reactions?.like ?? 0);
        setDislikeCount((data as any)?.reactions?.dislike ?? 0);

        if (currentUser) {
          const vote = (data as any)?.userVotes?.[currentUser.uid] || 
                       (data.reactions?.userReactions?.[currentUser.uid] as any);
          if (vote === "like" || vote === "dislike") {
            setUserReaction(vote);
          }
        }
      } else {
        setPost(FALLBACK_POST);
        setLikeCount(FALLBACK_POST.reactions?.like || 14);
      }
      setLoading(false);
    });

    // Real-time comments sync
    const commentsQ = query(
      collection(db, "news_posts", id, "comments"),
      orderBy("createdAt", "asc")
    );
    const unsubComments = onSnapshot(
      commentsQ,
      (snapshot) => {
        if (!snapshot.empty) {
          const fetched = snapshot.docs.map((docSnap) => ({
            id: docSnap.id,
            ...docSnap.data(),
          })) as NewsComment[];
          const visibleComments = fetched.filter((c) => {
            if (c.status === "published" || !c.status) return true;
            if (isAdmin) return true;
            if (currentUser && c.authorId === currentUser.uid) return true;
            return false;
          });
          setComments([...INITIAL_DEMO_COMMENTS, ...visibleComments]);
        } else {
          setComments(INITIAL_DEMO_COMMENTS);
        }
      },
      () => {
        setComments(INITIAL_DEMO_COMMENTS);
      }
    );

    return () => {
      unsubPost();
      unsubComments();
    };
  }, [id, currentUser?.uid]);

  // 1 Like / Dislike Per User ID strictly enforced
  const handleLike = async () => {
    if (!currentUser) {
      notify("Please sign in to react to this report", "info");
      navigate("/signin");
      return;
    }

    const currentPostId = post?.id || id || FALLBACK_POST.id;
    const isCurrentlyLiked = userReaction === "like";
    const newReaction = isCurrentlyLiked ? null : "like";

    setUserReaction(newReaction);
    setLikeCount((prev) => (isCurrentlyLiked ? Math.max(0, prev - 1) : prev + 1));
    if (userReaction === "dislike") {
      setDislikeCount((prev) => Math.max(0, prev - 1));
    }
    notify(isCurrentlyLiked ? "Like removed" : "Liked!", "success");

    if (currentPostId !== FALLBACK_POST.id) {
      try {
        const postRef = doc(db, "news_posts", currentPostId);
        await updateDoc(postRef, {
          "reactions.like": increment(isCurrentlyLiked ? -1 : 1),
          [`userVotes.${currentUser.uid}`]: newReaction || "",
          [`reactions.userReactions.${currentUser.uid}`]: newReaction || "",
        });
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleDislike = async () => {
    if (!currentUser) {
      notify("Please sign in to react", "info");
      navigate("/signin");
      return;
    }

    const currentPostId = post?.id || id || FALLBACK_POST.id;
    const isCurrentlyDisliked = userReaction === "dislike";
    const newReaction = isCurrentlyDisliked ? null : "dislike";

    setUserReaction(newReaction);
    setDislikeCount((prev) => (isCurrentlyDisliked ? Math.max(0, prev - 1) : prev + 1));
    if (userReaction === "like") {
      setLikeCount((prev) => Math.max(0, prev - 1));
    }
    notify(isCurrentlyDisliked ? "Feedback removed" : "Feedback noted", "info");

    if (currentPostId !== FALLBACK_POST.id) {
      try {
        const postRef = doc(db, "news_posts", currentPostId);
        await updateDoc(postRef, {
          "reactions.like": userReaction === "like" ? increment(-1) : increment(0),
          [`userVotes.${currentUser.uid}`]: newReaction || "",
          [`reactions.userReactions.${currentUser.uid}`]: newReaction || "",
        });
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Toggle Bookmark and persist in localStorage
  const handleToggleBookmark = () => {
    const currentPostId = post?.id || id || FALLBACK_POST.id;
    const nextSaved = !isSaved;
    setIsSaved(nextSaved);
    try {
      const stored = localStorage.getItem("deepshop_saved_news_ids");
      const map = stored ? JSON.parse(stored) : {};
      map[currentPostId] = nextSaved;
      localStorage.setItem("deepshop_saved_news_ids", JSON.stringify(map));
    } catch (err) {
      console.error(err);
    }
    notify(nextSaved ? "Saved to your bookmarks!" : "Removed from bookmarks", "success");
  };

  // Handle Scam Voting with instant local update and Firestore persistence (1 vote per user)
  const handleScamVote = async (choice: VoteChoice) => {
    if (!currentUser) {
      notify("Please sign in with your account to vote", "warning");
      navigate("/signin");
      return;
    }

    const currentPostId = post?.id || id || FALLBACK_POST.id;
    const voterId = currentUser.uid;

    const prevVotes = post?.scamVotes || {
      scammerCount: 1,
      suspiciousCount: 0,
      innocentCount: 0,
      userVotes: {},
    };

    const prevUserChoice = prevVotes.userVotes?.[voterId] || 
      (localStorage.getItem(`deepshop_scam_vote_${currentPostId}`) as VoteChoice) || null;

    let newScammer = prevVotes.scammerCount || 0;
    let newSuspicious = prevVotes.suspiciousCount || 0;
    let newInnocent = prevVotes.innocentCount || 0;
    const newUserVotes = { ...(prevVotes.userVotes || {}) };

    if (prevUserChoice === choice) {
      // Toggle off
      if (choice === "scammer") newScammer = Math.max(0, newScammer - 1);
      if (choice === "suspicious") newSuspicious = Math.max(0, newSuspicious - 1);
      if (choice === "innocent") newInnocent = Math.max(0, newInnocent - 1);
      delete newUserVotes[voterId];
      localStorage.removeItem(`deepshop_scam_vote_${currentPostId}`);
    } else {
      // Deduct previous choice
      if (prevUserChoice === "scammer") newScammer = Math.max(0, newScammer - 1);
      if (prevUserChoice === "suspicious") newSuspicious = Math.max(0, newSuspicious - 1);
      if (prevUserChoice === "innocent") newInnocent = Math.max(0, newInnocent - 1);

      // Add new choice
      if (choice === "scammer") newScammer += 1;
      if (choice === "suspicious") newSuspicious += 1;
      if (choice === "innocent") newInnocent += 1;

      newUserVotes[voterId] = choice;
      localStorage.setItem(`deepshop_scam_vote_${currentPostId}`, choice);
    }

    const updatedVotes = {
      scammerCount: newScammer,
      suspiciousCount: newSuspicious,
      innocentCount: newInnocent,
      userVotes: newUserVotes,
    };

    setPost((prev) => prev ? { ...prev, scamVotes: updatedVotes } : null);

    if (currentPostId !== FALLBACK_POST.id && currentPostId !== "test_demo_1") {
      try {
        await updateDoc(doc(db, "news_posts", currentPostId), {
          scamVotes: updatedVotes,
        });
      } catch (err) {
        console.error("Failed to update scam votes in Firestore", err);
      }
    }
  };

  // Toggle Follow Author
  const handleToggleFollow = () => {
    if (!currentUser) {
      notify("Please sign in to follow this investigator", "info");
      return;
    }
    setIsFollowingAuthor(!isFollowingAuthor);
    notify(!isFollowingAuthor ? "Now following this author!" : "Unfollowed", "success");
  };

  // Toggle Follow Topic
  const handleToggleFollowTopic = () => {
    setIsFollowingTopic(!isFollowingTopic);
    notify(!isFollowingTopic ? "Topic followed!" : "Unfollowed topic", "success");
  };

  // Stealth Admin Upload Post Image
  const handleAdminPostImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingPostImage(true);
    try {
      const { file: stampedFile } = await applyWatermarkToImage(file, {
        watermarkText: "Revealed On DEEP SHOP",
        subText: "OFFICIAL VIGILANCE REPORT",
        opacity: 0.25,
      });

      const uploadedUrl = await uploadToImgbb(stampedFile);
      setEditPostImages((prev) => [...prev, uploadedUrl]);
      notify("Watermarked image attached!", "success");
    } catch {
      notify("Failed to watermark image", "error");
    } finally {
      setIsUploadingPostImage(false);
    }
  };

  // Stealth Admin Save Edit
  const handleSavePostEdit = async () => {
    if (!post) return;
    try {
      if (post.id !== FALLBACK_POST.id) {
        await updateDoc(doc(db, "news_posts", post.id), {
          title: editPostTitle.trim(),
          content: editPostContent.trim(),
          images: editPostImages,
          coverImage: editPostImages[0] || "",
          updatedAt: Date.now(),
        });
      }
      setPost((prev) => prev ? { 
        ...prev, 
        title: editPostTitle.trim(), 
        content: editPostContent.trim(),
        images: editPostImages,
        coverImage: editPostImages[0] || ""
      } : prev);
      notify("Report updated quietly", "success");
      setIsEditingPost(false);
    } catch {
      notify("Failed to update post", "error");
    }
  };

  // Stealth Admin Delete Post
  const handleDeleteCurrentPost = async () => {
    if (!window.confirm("Permanently delete this report?")) return;
    try {
      if (post && post.id !== FALLBACK_POST.id) {
        await deleteDoc(doc(db, "news_posts", post.id));
      }
      notify("Report removed", "success");
      navigate("/news-hub");
    } catch {
      notify("Failed to delete post", "error");
    }
  };

  // Image Upload with Watermark for comment
  const handleCommentPhotoPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsWatermarkingCommentPhoto(true);
    try {
      const { file: stampedFile } = await applyWatermarkToImage(file, {
        watermarkText: "Revealed On DEEP SHOP",
        subText: "VERIFIED DISCUSSION COMMENT",
        opacity: 0.25,
      });

      const uploadedUrl = await uploadToImgbb(stampedFile);
      setCommentPhoto(uploadedUrl);
      notify("Photo uploaded with watermark verification!", "success");
    } catch {
      notify("Failed to watermark and upload image", "error");
    } finally {
      setIsWatermarkingCommentPhoto(false);
    }
  };

  // Submit comment or reply with mentions notification
  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() && !commentPhoto) return;

    if (!currentUser) {
      notify("Please sign in to join the discussion!", "warning");
      navigate("/signin");
      return;
    }

    setIsSubmittingComment(true);
    try {
      const currentPostId = post?.id || id || FALLBACK_POST.id;
      const text = newCommentText.trim();
      const needsReview = checkNeedsAdminReview(text);
      const commentStatus = needsReview ? "pending_admin_review" : "published";

      const newComment: Partial<NewsComment> = {
        postId: currentPostId,
        authorId: currentUser.uid,
        authorName: currentUser.displayName || currentUser.email?.split("@")[0] || "Deep Shop Member",
        authorAvatar: currentUser.photoURL || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120",
        isVerified: true,
        content: text,
        imageUrl: commentPhoto || undefined,
        createdAt: Date.now(),
        status: commentStatus,
        likesCount: 0,
        likedBy: [],
        parentCommentId: replyingTo ? replyingTo.id : undefined,
        replyToName: replyingTo ? replyingTo.authorName : undefined,
      };

      if (currentPostId !== FALLBACK_POST.id) {
        await addDoc(collection(db, "news_posts", currentPostId, "comments"), newComment);
        await updateDoc(doc(db, "news_posts", currentPostId), {
          commentsCount: increment(1),
        });

        // Mention or Reply Notification
        const targetUserId = replyingTo ? replyingTo.authorId : post?.authorId;
        if (targetUserId && targetUserId !== currentUser.uid) {
          try {
            await addDoc(collection(db, "notifications"), {
              userId: targetUserId,
              title: replyingTo ? "New reply on your comment" : "New comment on your vigilance report",
              message: `${currentUser.displayName || "Someone"} replied: "${text.slice(0, 70)}"`,
              link: `/news-hub/${currentPostId}`,
              type: "mention",
              isRead: false,
              createdAt: Date.now(),
            });
          } catch (notifErr) {
            console.error("Failed to send notification", notifErr);
          }
        }
      } else {
        setComments((prev) => [
          ...prev,
          { id: `c_${Date.now()}`, ...(newComment as NewsComment) },
        ]);
      }

      setNewCommentText("");
      setCommentPhoto("");
      setReplyingTo(null);
      notify(replyingTo ? "Reply posted!" : "Comment posted!", "success");

      setTimeout(() => {
        commentsEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 200);
    } catch {
      notify("Failed to post comment", "error");
    } finally {
      setIsSubmittingComment(false);
    }
  };

  // 1-Like-Per-User-ID for comments
  const handleLikeComment = async (comment: NewsComment) => {
    if (!currentUser) {
      notify("Please sign in to like this comment", "info");
      navigate("/signin");
      return;
    }

    const currentPostId = post?.id || id || FALLBACK_POST.id;
    const likedBy = comment.likedBy || [];
    const isLiked = likedBy.includes(currentUser.uid);

    setComments((prev) =>
      prev.map((c) => {
        if (c.id === comment.id) {
          const nextLikedBy = isLiked
            ? c.likedBy?.filter((u) => u !== currentUser.uid) || []
            : [...(c.likedBy || []), currentUser.uid];
          return {
            ...c,
            likedBy: nextLikedBy,
            likesCount: nextLikedBy.length,
          };
        }
        return c;
      })
    );

    if (currentPostId !== FALLBACK_POST.id) {
      try {
        const commentRef = doc(db, "news_posts", currentPostId, "comments", comment.id);
        await updateDoc(commentRef, {
          likedBy: isLiked ? arrayRemove(currentUser.uid) : arrayUnion(currentUser.uid),
          likesCount: increment(isLiked ? -1 : 1),
        });
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Stealth Comment Edit (Text + Remove Image)
  const handleSaveCommentEdit = async (commentId: string) => {
    if (!editCommentText.trim()) return;
    const currentPostId = post?.id || id || FALLBACK_POST.id;

    setComments((prev) =>
      prev.map((c) =>
        c.id === commentId
          ? { ...c, content: editCommentText.trim(), imageUrl: editCommentImage }
          : c
      )
    );

    if (currentPostId !== FALLBACK_POST.id) {
      try {
        await updateDoc(doc(db, "news_posts", currentPostId, "comments", commentId), {
          content: editCommentText.trim(),
          imageUrl: editCommentImage || null,
          updatedAt: Date.now(),
        });
      } catch (err) {
        console.error(err);
      }
    }

    notify("Comment updated quietly", "success");
    setEditingCommentId(null);
    setEditCommentText("");
    setEditCommentImage("");
  };

  // Stealth Comment Delete
  const handleDeleteComment = async (commentId: string) => {
    if (!window.confirm("Remove this comment?")) return;
    const currentPostId = post?.id || id || FALLBACK_POST.id;

    setComments((prev) => prev.filter((c) => c.id !== commentId && c.parentCommentId !== commentId));

    if (currentPostId !== FALLBACK_POST.id) {
      try {
        await deleteDoc(doc(db, "news_posts", currentPostId, "comments", commentId));
        await updateDoc(doc(db, "news_posts", currentPostId), {
          commentsCount: increment(-1),
        });
      } catch (err) {
        console.error(err);
      }
    }
    notify("Comment removed", "success");
    setActiveMenuCommentId(null);
  };

  const currentPost = post || FALLBACK_POST;

  const rootComments = comments.filter((c) => !c.parentCommentId);
  const getRepliesForComment = (parentId: string) => comments.filter((c) => c.parentCommentId === parentId);

  return (
    <div className="min-h-screen bg-[#fbfbfb] dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 pb-28 select-none font-sans">
      {/* Top Navigation Bar */}
      <div className="sticky top-0 z-30 bg-[#fbfbfb]/95 dark:bg-zinc-950/95 backdrop-blur-md px-4 py-3 max-w-xl md:max-w-3xl lg:max-w-4xl mx-auto flex items-center justify-between border-b border-zinc-100/80 dark:border-zinc-800/80">
        {/* Left: Back Arrow */}
        <button
          type="button"
          onClick={() => navigate("/news-hub")}
          className="w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800 flex items-center justify-center text-zinc-800 dark:text-zinc-200 shadow-xs hover:bg-zinc-50 active:scale-95 transition cursor-pointer"
          title="Back"
        >
          <ArrowLeft className="w-4 h-4 stroke-[2.2]" />
        </button>

        {/* Center / Right: "+ Follow This Topic" Single-Line Capsule Button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleToggleFollowTopic}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[11px] font-semibold shadow-xs transition-all cursor-pointer whitespace-nowrap leading-none ${
              isFollowingTopic
                ? "bg-[#86c857] text-white"
                : "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-50 active:scale-95"
            }`}
          >
            {isFollowingTopic ? (
              <>
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                <span className="whitespace-nowrap">Following Topic</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span className="whitespace-nowrap">Follow This Topic</span>
              </>
            )}
          </button>

          {/* Three-dots menu */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowMenu(!showMenu)}
              className="w-9 h-9 rounded-full bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800 flex items-center justify-center text-zinc-800 dark:text-zinc-200 shadow-xs hover:bg-zinc-50 active:scale-95 transition cursor-pointer"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-11 z-30 w-44 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-100 dark:border-zinc-800 py-1 text-xs text-zinc-700 dark:text-zinc-200">
                <button
                  type="button"
                  onClick={() => {
                    handleToggleBookmark();
                    setShowMenu(false);
                  }}
                  className="w-full px-3 py-2 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  <span className="whitespace-nowrap">{isSaved ? "Remove Bookmark" : "Save Bookmark"}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    notify("Link copied to clipboard!", "success");
                    setShowMenu(false);
                  }}
                  className="w-full px-3 py-2 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span className="whitespace-nowrap">Share Report</span>
                </button>

                {/* Stealth Admin Options */}
                {isAdmin && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setEditPostTitle(currentPost.title);
                        setEditPostContent(currentPost.content);
                        setEditPostImages(currentPost.images && currentPost.images.length > 0 ? [...currentPost.images] : currentPost.coverImage ? [currentPost.coverImage] : []);
                        setIsEditingPost(true);
                        setShowMenu(false);
                      }}
                      className="w-full px-3 py-2 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 border-t border-zinc-100 dark:border-zinc-800 whitespace-nowrap"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span className="whitespace-nowrap">Edit Report & Images</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleDeleteCurrentPost();
                        setShowMenu(false);
                      }}
                      className="w-full px-3 py-2 text-left hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 flex items-center gap-2 whitespace-nowrap"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span className="whitespace-nowrap">Delete Report</span>
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-xl md:max-w-3xl lg:max-w-4xl mx-auto px-4 pt-3 space-y-5">
        {/* Post Metadata */}
        <p className="text-[11px] text-zinc-400 font-medium whitespace-nowrap">
          Posted {currentPost.publishedAtStr || "Recent"}
        </p>

        {/* Post Title */}
        <h1 className="text-xl sm:text-[24px] font-bold text-zinc-900 dark:text-white leading-tight tracking-tight">
          {currentPost.title}
        </h1>

        {/* Hashtags Row (Single-line pills with whitespace-nowrap) */}
        <div className="flex items-center gap-1.5 flex-nowrap overflow-x-auto no-scrollbar py-0.5">
          {(currentPost.tags || ["#scamalert", "#fraud"]).map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 text-[11px] font-medium whitespace-nowrap shrink-0 leading-none"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Post Body Content with "View More ∨" */}
        <div className="text-sm sm:text-[15px] text-zinc-700 dark:text-zinc-300 leading-relaxed space-y-2">
          <p className={!isExpanded ? "line-clamp-5 whitespace-pre-line" : "whitespace-pre-line"}>
            {currentPost.content}
          </p>

          {currentPost.content.length > 200 && (
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-xs font-bold text-zinc-900 dark:text-white flex items-center gap-1 hover:underline cursor-pointer pt-1"
            >
              <span>{isExpanded ? "View Less ∧" : "View More ∨"}</span>
            </button>
          )}
        </div>

        {/* Beautiful Evidence / Attached Images */}
        {currentPost.images && currentPost.images.length > 0 && (
          <div className="pt-2 rounded-2xl overflow-hidden shadow-sm">
            <WatermarkedImageViewer images={currentPost.images} />
          </div>
        )}

        {/* Scam Report Alert Banner & Voting if scam */}
        {currentPost.isScamReport && (
          <div className="mt-3 p-3 sm:p-4 rounded-2xl bg-red-50/80 dark:bg-red-950/40 border border-red-200 dark:border-red-900 space-y-2">
            <div className="flex items-center gap-2 text-red-600 font-bold text-xs uppercase tracking-wide">
              <AlertTriangle className="w-4 h-4" />
              <span>Verified Scam Allegation Details</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs text-zinc-700 dark:text-zinc-300">
              {currentPost.scammerName && <div><span className="font-semibold">Reported Seller:</span> {currentPost.scammerName}</div>}
              {currentPost.scammerPhone && <div><span className="font-semibold">Phone/bKash:</span> {currentPost.scammerPhone}</div>}
              {currentPost.scammedAmount && <div><span className="font-semibold">Amount:</span> ৳{currentPost.scammedAmount.toLocaleString()}</div>}
            </div>
            <ScamVotingCard
              postId={currentPost.id}
              votes={currentPost.scamVotes}
              onVote={handleScamVote}
            />
          </div>
        )}

        {/* Action / Engagement Bar: Raw Real Counts */}
        <div className="rounded-full bg-zinc-100 dark:bg-zinc-800/80 px-4 py-2.5 flex items-center justify-between text-zinc-600 dark:text-zinc-300 shadow-inner">
          {/* Left: Thumbs Up (Raw Count) and Thumbs Down (1-vote per ID) */}
          <div className="flex items-center gap-4 text-xs font-semibold">
            <button
              type="button"
              onClick={handleLike}
              className={`flex items-center gap-1.5 transition active:scale-95 cursor-pointer whitespace-nowrap ${
                userReaction === "like" ? "text-blue-600 font-bold" : "hover:text-zinc-900 dark:hover:text-white"
              }`}
            >
              <ThumbsUp className={`w-4 h-4 ${userReaction === "like" ? "fill-current" : ""}`} />
              <span>{likeCount}</span>
            </button>

            <button
              type="button"
              onClick={handleDislike}
              className={`flex items-center gap-1 transition active:scale-95 cursor-pointer ${
                userReaction === "dislike" ? "text-red-500 font-bold" : "hover:text-zinc-900 dark:hover:text-white"
              }`}
            >
              <ThumbsDown className={`w-4 h-4 ${userReaction === "dislike" ? "fill-current" : ""}`} />
            </button>
          </div>

          {/* Right: Comments (Raw count) and Bookmark */}
          <div className="flex items-center gap-4 text-xs font-semibold">
            <button
              type="button"
              onClick={() => commentsEndRef.current?.scrollIntoView({ behavior: "smooth" })}
              className="flex items-center gap-1.5 hover:text-zinc-900 dark:hover:text-white transition cursor-pointer whitespace-nowrap"
            >
              <MessageSquare className="w-4 h-4" />
              <span>{comments.length}</span>
            </button>

            <button
              type="button"
              onClick={handleToggleBookmark}
              className={`flex items-center gap-1.5 transition active:scale-95 cursor-pointer whitespace-nowrap ${
                isSaved ? "text-[#86c857]" : "hover:text-zinc-900 dark:hover:text-white"
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? "fill-current" : ""}`} />
              <span>{isSaved ? "Saved" : "Save"}</span>
            </button>
          </div>
        </div>

        {/* Author Profile Card */}
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200/70 dark:border-zinc-800 rounded-2xl p-3.5 flex items-center justify-between gap-2 shadow-xs">
          <div 
            onClick={() => navigate(`/news-hub/user/${encodeURIComponent(currentPost.authorId || currentPost.authorName)}`, {
              state: {
                authorName: currentPost.authorName,
                authorAvatar: currentPost.authorAvatar,
                isVerified: currentPost.isAuthorVerified,
                isAdmin: currentPost.authorName?.toLowerCase().includes("deep") || currentPost.authorName?.toLowerCase().includes("tech"),
                isSeller: currentPost.authorName?.toLowerCase().includes("gadget") || currentPost.authorName?.toLowerCase().includes("seller"),
              }
            })}
            className="flex items-center gap-3 cursor-pointer hover:opacity-85 transition"
          >
            {currentPost.authorAvatar ? (
              <img
                src={currentPost.authorAvatar}
                alt={currentPost.authorName}
                className="w-11 h-11 rounded-full object-cover bg-zinc-100 ring-2 ring-[#86c857]/20 shrink-0"
              />
            ) : (
              <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-sm ring-2 ring-[#86c857]/20 shrink-0">
                {(currentPost.authorName || "U")[0].toUpperCase()}
              </div>
            )}
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-zinc-900 dark:text-white whitespace-nowrap hover:underline">
                  {currentPost.authorName}
                </span>
                {currentPost.isAuthorVerified && (
                  <VerifiedBadgeIcon className="w-4 h-4 shrink-0" />
                )}
              </div>
              <p className="text-[11px] text-zinc-400 whitespace-nowrap">View Profile • Community Reporter</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleToggleFollow}
              className={`flex items-center gap-1 px-3.5 py-1.5 rounded-full text-[11px] font-bold transition-all active:scale-95 cursor-pointer whitespace-nowrap leading-none ${
                isFollowingAuthor
                  ? "bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700"
                  : "bg-[#86c857] hover:bg-[#78be4a] text-white shadow-xs"
              }`}
            >
            {isFollowingAuthor ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span className="whitespace-nowrap">Following</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span className="whitespace-nowrap">Follow</span>
              </>
            )}
          </button>
        </div>
      </div>

        {/* Comments Section */}
        <div className="pt-3 space-y-3">
          <h2 className="text-base sm:text-lg font-bold text-zinc-900 dark:text-white">
            Comments ({comments.length})
          </h2>

          <div className="space-y-3">
            {rootComments.map((comment, index) => {
              const isFirst = index === 0;
              const replies = getRepliesForComment(comment.id);
              const isCommentLiked = currentUser && (comment.likedBy || []).includes(currentUser.uid);

              return (
                <div key={comment.id} className="space-y-2">
                  {/* Root Comment Card */}
                  <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/60 dark:border-zinc-800 shadow-xs space-y-2.5">
                    {/* Top user row */}
                    <div className="flex items-center justify-between gap-2">
                      <div 
                        onClick={() => navigate(`/news-hub/user/${encodeURIComponent(comment.authorId || comment.authorName)}`, {
                          state: {
                            authorName: comment.authorName,
                            authorAvatar: comment.authorAvatar,
                            isVerified: comment.isVerified,
                          }
                        })}
                        className="flex items-center gap-2 cursor-pointer hover:opacity-85 transition"
                      >
                        {comment.authorAvatar ? (
                          <img
                            src={comment.authorAvatar}
                            alt={comment.authorName}
                            className="w-8 h-8 rounded-full object-cover bg-zinc-100 shrink-0"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-xs shrink-0">
                            {(comment.authorName || "U")[0].toUpperCase()}
                          </div>
                        )}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-zinc-900 dark:text-white whitespace-nowrap hover:underline">
                            {comment.authorName}
                          </span>
                          {comment.isVerified && (
                            <VerifiedBadgeIcon className="w-3.5 h-3.5 shrink-0" />
                          )}
                          {comment.status === "pending_admin_review" && (
                            <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300 text-[10px] font-bold border border-amber-200 dark:border-amber-800">
                              Under Review
                            </span>
                          )}
                          <span className="text-[11px] text-zinc-400 font-medium whitespace-nowrap">
                            • Recent
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {isFirst && (comment.likesCount || 0) > 0 && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold whitespace-nowrap leading-none shrink-0">
                            <ThumbsUp className="w-2.5 h-2.5" />
                            <span className="whitespace-nowrap">Top</span>
                          </span>
                        )}

                        {/* Stealth Comment Three-Dots Menu */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={() =>
                              setActiveMenuCommentId(
                                activeMenuCommentId === comment.id ? null : comment.id
                              )
                            }
                            className="w-6 h-6 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 flex items-center justify-center cursor-pointer"
                          >
                            <MoreHorizontal className="w-3.5 h-3.5" />
                          </button>

                          {activeMenuCommentId === comment.id && (
                            <div className="absolute right-0 top-7 z-30 w-36 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-100 dark:border-zinc-800 py-1 text-xs text-zinc-700 dark:text-zinc-200">
                              <button
                                type="button"
                                onClick={() => {
                                  setReplyingTo(comment);
                                  setNewCommentText(`@${comment.authorName} `);
                                  setActiveMenuCommentId(null);
                                }}
                                className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 whitespace-nowrap"
                              >
                                <CornerDownRight className="w-3.5 h-3.5" />
                                <span className="whitespace-nowrap">Reply</span>
                              </button>

                              {/* Stealth Admin / Author actions */}
                              {(isAdmin || (currentUser && comment.authorId === currentUser.uid)) && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setEditingCommentId(comment.id);
                                      setEditCommentText(comment.content);
                                      setEditCommentImage(comment.imageUrl || "");
                                      setActiveMenuCommentId(null);
                                    }}
                                    className="w-full px-3 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-2 border-t border-zinc-100 dark:border-zinc-800 whitespace-nowrap"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                    <span className="whitespace-nowrap">Edit</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteComment(comment.id)}
                                    className="w-full px-3 py-1.5 text-left hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 flex items-center gap-2 whitespace-nowrap"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span className="whitespace-nowrap">Delete</span>
                                  </button>
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Comment text or Inline Edit */}
                    {editingCommentId === comment.id ? (
                      <div className="space-y-2 pt-1">
                        <textarea
                          rows={2}
                          value={editCommentText}
                          onChange={(e) => setEditCommentText(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#86c857]"
                        />
                        {editCommentImage && (
                          <div className="relative w-20 h-16 rounded-lg overflow-hidden border border-zinc-200 dark:border-zinc-700">
                            <img src={editCommentImage} alt="" className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => setEditCommentImage("")}
                              className="absolute top-1 right-1 w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center"
                              title="Remove image"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                        <div className="flex items-center gap-2 justify-end">
                          <button
                            type="button"
                            onClick={() => setEditingCommentId(null)}
                            className="px-3 py-1 rounded-full text-xs text-zinc-500 hover:bg-zinc-100"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSaveCommentEdit(comment.id)}
                            className="px-4 py-1 rounded-full bg-[#86c857] text-white text-xs font-bold shadow-xs cursor-pointer"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs sm:text-[13px] text-zinc-700 dark:text-zinc-300 leading-relaxed whitespace-pre-line">
                        {comment.content}
                      </p>
                    )}

                    {/* Comment image if attached */}
                    {comment.imageUrl && !editingCommentId && (
                      <div className="pt-1 rounded-xl overflow-hidden">
                        <WatermarkedImageViewer src={comment.imageUrl} aspectRatio="aspect-video" />
                      </div>
                    )}

                    {/* Comment interaction: 1 like per ID + Reply */}
                    <div className="flex items-center gap-4 pt-1 text-[11px] font-semibold text-zinc-400">
                      <button
                        type="button"
                        onClick={() => handleLikeComment(comment)}
                        className={`flex items-center gap-1 transition cursor-pointer whitespace-nowrap ${
                          isCommentLiked ? "text-blue-600 font-bold" : "hover:text-zinc-700 dark:hover:text-zinc-200"
                        }`}
                      >
                        <ThumbsUp className={`w-3 h-3 ${isCommentLiked ? "fill-current" : ""}`} />
                        <span>{comment.likesCount || 0}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setReplyingTo(comment);
                          setNewCommentText(`@${comment.authorName} `);
                        }}
                        className="hover:text-zinc-700 dark:hover:text-zinc-200 transition cursor-pointer whitespace-nowrap"
                      >
                        Reply
                      </button>
                    </div>
                  </div>

                  {/* Nested Replies matching comment card shape */}
                  {replies.length > 0 && (
                    <div className="pl-4 ml-3 border-l-2 border-zinc-200/80 dark:border-zinc-800 space-y-2">
                      {replies.map((reply) => {
                        const isReplyLiked = currentUser && (reply.likedBy || []).includes(currentUser.uid);
                        return (
                          <div
                            key={reply.id}
                            className="bg-white dark:bg-zinc-900 rounded-2xl p-3 border border-zinc-200/60 dark:border-zinc-800 shadow-xs space-y-2"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div 
                                onClick={() => navigate(`/news-hub/user/${encodeURIComponent(reply.authorId || reply.authorName)}`, {
                                  state: {
                                    authorName: reply.authorName,
                                    authorAvatar: reply.authorAvatar,
                                    isVerified: reply.isVerified,
                                  }
                                })}
                                className="flex items-center gap-2 cursor-pointer hover:opacity-85 transition"
                              >
                                {reply.authorAvatar ? (
                                  <img
                                    src={reply.authorAvatar}
                                    alt={reply.authorName}
                                    className="w-7 h-7 rounded-full object-cover bg-zinc-100 shrink-0"
                                  />
                                ) : (
                                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-[11px] shrink-0">
                                    {(reply.authorName || "U")[0].toUpperCase()}
                                  </div>
                                )}
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-xs font-bold text-zinc-900 dark:text-white whitespace-nowrap hover:underline">
                                    {reply.authorName}
                                  </span>
                                  {reply.isVerified && (
                                    <VerifiedBadgeIcon className="w-3.5 h-3.5 shrink-0" />
                                  )}
                                  <span className="text-[10px] text-zinc-400 font-medium whitespace-nowrap">
                                    • Recent
                                  </span>
                                </div>
                              </div>

                              {(isAdmin || (currentUser && reply.authorId === currentUser.uid)) && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteComment(reply.id)}
                                  className="text-zinc-400 hover:text-red-500 p-1"
                                  title="Delete reply"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>

                            <p className="text-xs text-zinc-700 dark:text-zinc-300 leading-relaxed whitespace-pre-line">
                              {reply.content}
                            </p>

                            <div className="flex items-center gap-3 pt-0.5 text-[10px] font-semibold text-zinc-400">
                              <button
                                type="button"
                                onClick={() => handleLikeComment(reply)}
                                className={`flex items-center gap-1 transition cursor-pointer whitespace-nowrap ${
                                  isReplyLiked ? "text-blue-600 font-bold" : "hover:text-zinc-700 dark:hover:text-zinc-200"
                                }`}
                              >
                                <ThumbsUp className={`w-3 h-3 ${isReplyLiked ? "fill-current" : ""}`} />
                                <span>{reply.likesCount || 0}</span>
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
            <div ref={commentsEndRef} />
          </div>
        </div>
      </div>

      {/* Stealth Admin Edit Post Modal (Content & Images) */}
      {isEditingPost && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 max-w-lg w-full space-y-4 border border-zinc-200 dark:border-zinc-800 shadow-2xl max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-zinc-900 dark:text-white">Edit Report & Evidence Images</h3>
              <button
                type="button"
                onClick={() => setIsEditingPost(false)}
                className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-zinc-500 mb-1 block">Title</label>
                <input
                  type="text"
                  value={editPostTitle}
                  onChange={(e) => setEditPostTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#86c857]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-500 mb-1 block">Content</label>
                <textarea
                  rows={4}
                  value={editPostContent}
                  onChange={(e) => setEditPostContent(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#86c857]"
                />
              </div>

              {/* Admin Images Management */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-zinc-500">Report Evidence Images</label>
                  <label className="text-xs font-bold text-[#86c857] flex items-center gap-1 cursor-pointer hover:underline">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleAdminPostImageUpload}
                      disabled={isUploadingPostImage}
                    />
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploadingPostImage ? "Watermarking..." : "Add Image"}</span>
                  </label>
                </div>

                {editPostImages.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {editPostImages.map((imgUrl, idx) => (
                      <div key={idx} className="relative rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-700 aspect-video group/img">
                        <img src={imgUrl} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setEditPostImages(prev => prev.filter((_, i) => i !== idx))}
                          className="absolute top-1 right-1 w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center shadow-md hover:bg-red-700 cursor-pointer"
                          title="Remove image"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-zinc-400 italic">No images attached.</p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditingPost(false)}
                className="px-4 py-2 rounded-full text-xs font-semibold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSavePostEdit}
                className="px-5 py-2 rounded-full bg-[#86c857] hover:bg-[#78be4a] text-white text-xs font-bold shadow-xs active:scale-95 transition cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Bottom Comment Input Bar */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md border-t border-zinc-200/70 dark:border-zinc-800 p-3 pb-safe">
        {/* Reply Indicator Bar */}
        {replyingTo && (
          <div className="max-w-xl md:max-w-3xl lg:max-w-4xl mx-auto mb-2 flex items-center justify-between px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-xs text-zinc-600 dark:text-zinc-300">
            <span className="flex items-center gap-1.5 truncate">
              <CornerDownRight className="w-3.5 h-3.5 text-[#86c857]" />
              <span>Replying to <strong className="text-zinc-900 dark:text-white">@{replyingTo.authorName}</strong></span>
            </span>
            <button
              type="button"
              onClick={() => {
                setReplyingTo(null);
                setNewCommentText("");
              }}
              className="text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <form
          onSubmit={handleSubmitComment}
          className="max-w-xl md:max-w-3xl lg:max-w-4xl mx-auto flex items-center gap-2 relative"
        >
          {/* Add media attachment button */}
          <label
            className="w-9 h-9 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition cursor-pointer shrink-0"
            title="Attach watermarked screenshot / image"
          >
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleCommentPhotoPick}
              disabled={isWatermarkingCommentPhoto}
            />
            <Plus className="w-5 h-5 stroke-[2.2]" />
          </label>

          {/* Comment input field */}
          <input
            type="text"
            value={newCommentText}
            onChange={(e) => setNewCommentText(e.target.value)}
            placeholder={replyingTo ? `Reply to @${replyingTo.authorName}...` : "Add a comment"}
            className="flex-1 bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white text-xs sm:text-sm px-4 py-2.5 rounded-full border-none focus:outline-none focus:ring-1 focus:ring-[#86c857] shadow-inner placeholder:text-zinc-400"
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={isSubmittingComment || (!newCommentText.trim() && !commentPhoto)}
            className="w-9 h-9 rounded-full bg-transparent flex items-center justify-center text-zinc-700 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-white disabled:opacity-40 active:scale-95 transition cursor-pointer shrink-0"
            title="Send Comment"
          >
            <Send className="w-5 h-5 stroke-[2]" />
          </button>

          {/* Preview of attached photo if any */}
          {commentPhoto && (
            <div className="absolute -top-14 left-12 flex items-center gap-2 p-1.5 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-md">
              <img src={commentPhoto} alt="" className="w-10 h-10 rounded-lg object-cover" />
              <button
                type="button"
                onClick={() => setCommentPhoto("")}
                className="w-5 h-5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-500 flex items-center justify-center"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {isWatermarkingCommentPhoto && (
            <div className="absolute -top-10 left-4 text-xs font-semibold text-[#86c857] bg-white dark:bg-zinc-900 px-3 py-1 rounded-full shadow-sm border border-zinc-100 dark:border-zinc-800 whitespace-nowrap">
              Applying watermark & uploading...
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
