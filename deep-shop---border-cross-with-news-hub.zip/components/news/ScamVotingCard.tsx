import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AlertTriangle, Users, CheckCircle2, ShieldAlert, ShieldCheck } from "lucide-react";
import { auth } from "../../firebase";
import { useNotify } from "../Notifications";

export type VoteChoice = "scammer" | "suspicious" | "innocent";

interface ScamVotingCardProps {
  postId: string;
  votes?: {
    scammerCount?: number;
    suspiciousCount?: number;
    innocentCount?: number;
    userVotes?: Record<string, VoteChoice>;
  };
  currentUserVote?: VoteChoice | null;
  onVote: (choice: VoteChoice) => void;
  disabled?: boolean;
}

export const ScamVotingCard: React.FC<ScamVotingCardProps> = ({
  postId,
  votes = {},
  currentUserVote,
  onVote,
  disabled = false,
}) => {
  const notify = useNotify();
  const navigate = useNavigate();
  const location = useLocation();
  const currentUser = auth.currentUser;

  // Persistent voter ID (supports both logged-in users and guests via localStorage)
  const [voterId] = useState<string>(() => {
    if (currentUser?.uid) return currentUser.uid;
    let stored = localStorage.getItem("deepshop_device_voter_id");
    if (!stored) {
      stored = "guest_voter_" + Math.random().toString(36).substring(2, 10);
      localStorage.setItem("deepshop_device_voter_id", stored);
    }
    return stored;
  });

  // Local optimistic state for instant UI response
  const [localVote, setLocalVote] = useState<VoteChoice | null>(() => {
    if (currentUserVote) return currentUserVote;
    if (votes.userVotes && votes.userVotes[voterId]) {
      return votes.userVotes[voterId];
    }
    const localSaved = localStorage.getItem(`deepshop_scam_vote_${postId}`);
    return (localSaved as VoteChoice) || null;
  });

  const [localCounts, setLocalCounts] = useState({
    scammer: votes.scammerCount ?? 1,
    suspicious: votes.suspiciousCount ?? 0,
    innocent: votes.innocentCount ?? 0,
  });

  // Sync when prop votes change
  useEffect(() => {
    setLocalCounts({
      scammer: votes.scammerCount ?? 1,
      suspicious: votes.suspiciousCount ?? 0,
      innocent: votes.innocentCount ?? 0,
    });
    if (currentUserVote) {
      setLocalVote(currentUserVote);
    } else if (votes.userVotes && votes.userVotes[voterId]) {
      setLocalVote(votes.userVotes[voterId]);
    }
  }, [votes.scammerCount, votes.suspiciousCount, votes.innocentCount, currentUserVote, votes.userVotes, voterId]);

  const scammerCount = localCounts.scammer;
  const suspiciousCount = localCounts.suspicious;
  const innocentCount = localCounts.innocent;
  const totalVotes = scammerCount + suspiciousCount + innocentCount;

  const scammerPct = totalVotes > 0 ? Math.round((scammerCount / totalVotes) * 100) : 0;
  const suspiciousPct = totalVotes > 0 ? Math.round((suspiciousCount / totalVotes) * 100) : 0;
  const innocentPct = totalVotes > 0 ? Math.round((innocentCount / totalVotes) * 100) : 0;

  const handleVoteClick = (choice: VoteChoice) => {
    if (disabled) return;

    if (!currentUser) {
      notify("Please sign in with your account to vote", "warning");
      navigate("/signin", { state: { from: location.pathname } });
      return;
    }

    const previousVote = localVote;
    let nextVote: VoteChoice | null = choice;

    const updatedCounts = { ...localCounts };

    if (previousVote === choice) {
      // Toggle off if clicked same choice
      nextVote = null;
      updatedCounts[choice] = Math.max(0, updatedCounts[choice] - 1);
      localStorage.removeItem(`deepshop_scam_vote_${postId}`);
      notify("Your vote was removed", "info");
    } else {
      // Switch or new vote
      if (previousVote) {
        updatedCounts[previousVote] = Math.max(0, updatedCounts[previousVote] - 1);
      }
      updatedCounts[choice] = (updatedCounts[choice] || 0) + 1;
      localStorage.setItem(`deepshop_scam_vote_${postId}`, choice);
      
      const label = choice === "scammer" ? "SCAMMER" : choice === "suspicious" ? "SUSPICIOUS" : "INNOCENT";
      notify(`Your vote for ${label} has been recorded!`, "success");
    }

    setLocalVote(nextVote);
    setLocalCounts(updatedCounts);

    // Call parent handler
    onVote(choice);
  };

  // Determine community verdict without emojis, using SVG icons
  let verdictText = "Awaiting Community Votes";
  let verdictColor = "text-zinc-500 bg-zinc-100 dark:bg-zinc-800";
  let VerdictIcon: React.ComponentType<{ className?: string }> | null = null;

  if (totalVotes > 0) {
    if (scammerPct >= 50) {
      verdictText = `${scammerPct}% Verdict: CONFIRMED SCAMMER`;
      verdictColor = "text-red-600 bg-red-100/90 dark:bg-red-950/70 border border-red-200 dark:border-red-900";
      VerdictIcon = ShieldAlert;
    } else if (innocentPct >= 50) {
      verdictText = `${innocentPct}% Verdict: INNOCENT / RESOLVED`;
      verdictColor = "text-emerald-600 bg-emerald-100/90 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-900";
      VerdictIcon = ShieldCheck;
    } else {
      verdictText = `${suspiciousPct + scammerPct}% Verdict: SUSPICIOUS ACTIVITY`;
      verdictColor = "text-amber-600 bg-amber-100/90 dark:bg-amber-950/70 border border-amber-200 dark:border-amber-900";
      VerdictIcon = AlertTriangle;
    }
  }

  return (
    <div className="p-3 sm:p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm space-y-3 sm:space-y-4">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-red-100 dark:bg-red-950/60 flex items-center justify-center text-red-600 shrink-0">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black text-zinc-900 dark:text-white leading-tight">
              Community Fraud Jury & Public Vote
            </h4>
            <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px] text-zinc-500 font-medium">
              <Users className="w-3 h-3" />
              <span>{totalVotes} members voted (1 vote per user)</span>
            </div>
          </div>
        </div>

        {/* Verdict Badge - Strictly single-line with Lucide SVG icon */}
        <div className={`px-2 sm:px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 self-start sm:self-center flex items-center gap-1.5 max-w-full ${verdictColor}`}>
          {VerdictIcon && <VerdictIcon className="w-3.5 h-3.5 shrink-0" />}
          <span className="truncate">{verdictText}</span>
        </div>
      </div>

      {/* Multi-segment Progress Bar */}
      <div className="w-full h-2 sm:h-2.5 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden flex">
        {totalVotes === 0 ? (
          <div className="w-full h-full bg-zinc-200 dark:bg-zinc-700" />
        ) : (
          <>
            <div
              style={{ width: `${scammerPct}%` }}
              className="h-full bg-red-600 transition-all duration-300"
              title={`Scammer: ${scammerPct}%`}
            />
            <div
              style={{ width: `${suspiciousPct}%` }}
              className="h-full bg-amber-500 transition-all duration-300"
              title={`Suspicious: ${suspiciousPct}%`}
            />
            <div
              style={{ width: `${innocentPct}%` }}
              className="h-full bg-emerald-500 transition-all duration-300"
              title={`Innocent: ${innocentPct}%`}
            />
          </>
        )}
      </div>

      {/* 3 Voting Buttons - Strict Single-Line Pill Shape with responsive small font scaling & Lucide SVG icons */}
      <div className="grid grid-cols-3 gap-1 sm:gap-2">
        {/* 1. Scammer Pill */}
        <button
          type="button"
          disabled={disabled}
          onClick={() => handleVoteClick("scammer")}
          className={`flex items-center justify-center gap-0.5 sm:gap-1.5 py-1.5 sm:py-2 px-1 sm:px-2.5 rounded-full border transition-all active:scale-95 cursor-pointer min-w-0 overflow-hidden leading-tight select-none ${
            localVote === "scammer"
              ? "bg-red-600 text-white border-red-700 shadow-md ring-2 ring-red-400/40"
              : "bg-zinc-50 dark:bg-zinc-800/90 hover:bg-red-50 dark:hover:bg-red-950/40 text-zinc-800 dark:text-zinc-200 border-zinc-200 dark:border-zinc-700"
          }`}
          title={`Scammer: ${scammerPct}% (${scammerCount})`}
        >
          <ShieldAlert className={`w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 ${localVote === "scammer" ? "text-white" : "text-red-500"}`} />
          <span className="text-[9px] min-[360px]:text-[10px] sm:text-xs font-bold sm:font-black tracking-tight whitespace-nowrap shrink-0">
            Scammer
          </span>
          <span className={`text-[8.5px] min-[360px]:text-[9.5px] sm:text-[11px] font-mono font-bold whitespace-nowrap shrink-0 ${localVote === "scammer" ? "text-red-100" : "text-zinc-400 dark:text-zinc-500"}`}>
            {scammerPct}%
          </span>
        </button>

        {/* 2. Suspicious Pill */}
        <button
          type="button"
          disabled={disabled}
          onClick={() => handleVoteClick("suspicious")}
          className={`flex items-center justify-center gap-0.5 sm:gap-1.5 py-1.5 sm:py-2 px-1 sm:px-2.5 rounded-full border transition-all active:scale-95 cursor-pointer min-w-0 overflow-hidden leading-tight select-none ${
            localVote === "suspicious"
              ? "bg-amber-500 text-white border-amber-600 shadow-md ring-2 ring-amber-400/40"
              : "bg-zinc-50 dark:bg-zinc-800/90 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-zinc-800 dark:text-zinc-200 border-zinc-200 dark:border-zinc-700"
          }`}
          title={`Suspicious: ${suspiciousPct}% (${suspiciousCount})`}
        >
          <AlertTriangle className={`w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 ${localVote === "suspicious" ? "text-white" : "text-amber-500"}`} />
          <span className="text-[9px] min-[360px]:text-[10px] sm:text-xs font-bold sm:font-black tracking-tight whitespace-nowrap shrink-0">
            Suspicious
          </span>
          <span className={`text-[8.5px] min-[360px]:text-[9.5px] sm:text-[11px] font-mono font-bold whitespace-nowrap shrink-0 ${localVote === "suspicious" ? "text-amber-100" : "text-zinc-400 dark:text-zinc-500"}`}>
            {suspiciousPct}%
          </span>
        </button>

        {/* 3. Innocent Pill */}
        <button
          type="button"
          disabled={disabled}
          onClick={() => handleVoteClick("innocent")}
          className={`flex items-center justify-center gap-0.5 sm:gap-1.5 py-1.5 sm:py-2 px-1 sm:px-2.5 rounded-full border transition-all active:scale-95 cursor-pointer min-w-0 overflow-hidden leading-tight select-none ${
            localVote === "innocent"
              ? "bg-emerald-600 text-white border-emerald-700 shadow-md ring-2 ring-emerald-400/40"
              : "bg-zinc-50 dark:bg-zinc-800/90 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-zinc-800 dark:text-zinc-200 border-zinc-200 dark:border-zinc-700"
          }`}
          title={`Innocent: ${innocentPct}% (${innocentCount})`}
        >
          <ShieldCheck className={`w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 ${localVote === "innocent" ? "text-white" : "text-emerald-500"}`} />
          <span className="text-[9px] min-[360px]:text-[10px] sm:text-xs font-bold sm:font-black tracking-tight whitespace-nowrap shrink-0">
            Innocent
          </span>
          <span className={`text-[8.5px] min-[360px]:text-[9.5px] sm:text-[11px] font-mono font-bold whitespace-nowrap shrink-0 ${localVote === "innocent" ? "text-emerald-100" : "text-zinc-400 dark:text-zinc-500"}`}>
            {innocentPct}%
          </span>
        </button>
      </div>

      <div className="flex items-center justify-between text-[10px] text-zinc-400 font-medium px-1">
        <span className="whitespace-nowrap">Single tap to cast or change vote</span>
        {localVote && (
          <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 whitespace-nowrap">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            <span>Voted: {localVote.toUpperCase()}</span>
          </span>
        )}
      </div>
    </div>
  );
};
