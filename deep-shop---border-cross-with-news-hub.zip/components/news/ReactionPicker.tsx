import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

const ThumbsUpIcon = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3z" />
    <path d="M7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" />
  </svg>
);

export type ReactionKey = "like" | "love" | "haha" | "wow" | "sad" | "angry" | "alert";

export interface ReactionItem {
  key: ReactionKey;
  label: string;
  emoji: string;
  color: string;
}

export const REACTIONS: ReactionItem[] = [
  { key: "like", label: "Like", emoji: "👍", color: "text-blue-500" },
  { key: "love", label: "Love", emoji: "❤️", color: "text-rose-500" },
  { key: "haha", label: "Haha", emoji: "😆", color: "text-amber-500" },
  { key: "wow", label: "Wow", emoji: "😮", color: "text-amber-500" },
  { key: "sad", label: "Sad", emoji: "😢", color: "text-amber-500" },
  { key: "angry", label: "Angry", emoji: "😡", color: "text-orange-600" },
  { key: "alert", label: "Scammer", emoji: "🚨", color: "text-red-600" },
];

interface ReactionPickerProps {
  currentReaction?: ReactionKey | null;
  totalReactions?: number;
  onReact: (reaction: ReactionKey) => void;
  size?: "sm" | "md";
  align?: "left" | "right" | "center";
}

export const ReactionPicker: React.FC<ReactionPickerProps> = ({
  currentReaction,
  totalReactions = 0,
  onReact,
  size = "md",
  align = "right", // default right-aligned so it never overflows off-screen on mobile!
}) => {
  const [showPicker, setShowPicker] = useState(false);
  const hoverTimeoutRef = useRef<any>(null);

  const activeReaction = REACTIONS.find((r) => r.key === currentReaction);

  const handleMouseEnter = () => {
    clearTimeout(hoverTimeoutRef.current);
    setShowPicker(true);
  };

  const handleMouseLeave = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setShowPicker(false);
    }, 450);
  };

  const handleTriggerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (showPicker) {
      setShowPicker(false);
    } else {
      setShowPicker(true);
    }
  };

  const formatCount = (count: number) => {
    if (count >= 1000) {
      return (count / 1000).toFixed(1).replace(/\.0$/, "") + "k";
    }
    return count.toString();
  };

  const alignClass =
    align === "left"
      ? "left-0 origin-bottom-left"
      : align === "center"
      ? "left-1/2 -translate-x-1/2 origin-bottom"
      : "right-0 origin-bottom-right";

  return (
    <div
      className="relative inline-flex items-center"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Floating Reaction Bar (Facebook Style) - Fixed mobile overflow */}
      <AnimatePresence>
        {showPicker && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.92 }}
            animate={{ opacity: 1, y: -42, scale: 1 }}
            exit={{ opacity: 0, y: 5, scale: 0.92 }}
            transition={{ type: "spring", stiffness: 450, damping: 26 }}
            className={`absolute bottom-full mb-1 z-50 flex items-center gap-1 sm:gap-1.5 px-2 py-1.5 bg-white dark:bg-zinc-800 rounded-full shadow-2xl border border-zinc-200/90 dark:border-zinc-700/90 max-w-[calc(100vw-32px)] ${alignClass}`}
            onClick={(e) => e.stopPropagation()}
          >
            {REACTIONS.map((r) => {
              const isSelected = currentReaction === r.key;
              return (
                <button
                  key={r.key}
                  type="button"
                  onClick={() => {
                    onReact(r.key);
                    setShowPicker(false);
                  }}
                  className={`p-1 sm:p-1.5 rounded-full hover:scale-125 active:scale-95 transition-transform flex flex-col items-center justify-center cursor-pointer ${
                    isSelected ? "ring-2 ring-blue-500 scale-110 bg-blue-50 dark:bg-blue-950/40" : ""
                  }`}
                  title={r.label}
                >
                  <span className="text-lg sm:text-xl leading-none select-none">{r.emoji}</span>
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trigger Button: Facebook Like Button or Active Reaction Badge */}
      <button
        type="button"
        onClick={handleTriggerClick}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition cursor-pointer select-none ${
          activeReaction
            ? "bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white"
            : "text-zinc-500 hover:text-zinc-800 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800"
        }`}
      >
        {activeReaction ? (
          <>
            <span className="text-sm leading-none">{activeReaction.emoji}</span>
            <span className={`text-[11px] font-extrabold ${activeReaction.color}`}>
              {activeReaction.label}
            </span>
          </>
        ) : (
          <>
            <ThumbsUpIcon className={size === "sm" ? "w-3.5 h-3.5" : "w-4 h-4"} />
            <span className="text-[11px]">React</span>
          </>
        )}

        {totalReactions > 0 && (
          <span className="text-[11px] text-zinc-400 font-mono font-bold">
            {formatCount(totalReactions)}
          </span>
        )}
      </button>
    </div>
  );
};
