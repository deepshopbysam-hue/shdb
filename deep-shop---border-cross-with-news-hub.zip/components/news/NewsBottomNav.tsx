import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Icon from "../Icon";
import { cn } from "../../lib/utils";

interface NewsBottomNavProps {
  onOpenCreate?: () => void;
  activeTab?: string;
  onTabChange?: (tab: string) => void;
  savedCount?: number;
}

export const NewsBottomNav: React.FC<NewsBottomNavProps> = ({
  activeTab = "home",
  onTabChange,
  onOpenCreate,
  savedCount,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNav = (tab: string, path?: string) => {
    if (tab === "create") {
      if (onOpenCreate) {
        onOpenCreate();
      } else {
        navigate("/news-hub/create");
      }
      return;
    }

    if (onTabChange) onTabChange(tab);
    if (path && location.pathname !== path) navigate(path);
  };

  const NavItem = ({
    icon,
    label,
    tab,
    path,
    badge,
  }: {
    icon: string;
    label: string;
    tab: string;
    path: string;
    badge?: number;
  }) => {
    const isCreateActive =
      tab === "create" &&
      (location.pathname.startsWith("/news-hub/create") ||
        location.pathname.startsWith("/news-hub/report"));

    const isProfileActive =
      tab === "profile" &&
      (location.pathname.startsWith("/news-hub/user") ||
        location.pathname === "/profile");

    const isTabActive =
      location.pathname === "/news-hub" && activeTab === tab;

    const isActive = isCreateActive || isProfileActive || isTabActive;

    return (
      <button
        type="button"
        onClick={() => handleNav(tab, path)}
        className={cn(
          "h-10 flex items-center justify-center transition-all duration-300 rounded-full cursor-pointer relative",
          isActive
            ? "bg-[#E8EAEE]/90 dark:bg-[#2D2E33]/90 text-zinc-950 dark:text-white px-3.5 sm:px-5 shadow-xs"
            : "px-2.5 sm:px-3.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
        )}
        title={label}
      >
        <div className="relative flex items-center gap-1.5">
          <Icon
            name={icon}
            className={cn(
              "w-5 h-5 transition-transform duration-300",
              isActive && "scale-105"
            )}
            solid={false}
          />
          {isActive && (
            <span className="text-xs font-bold whitespace-nowrap animate-in fade-in duration-200">
              {label}
            </span>
          )}
          {badge !== undefined && badge > 0 && (
            <span className="absolute -top-2 -right-2 bg-amber-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full min-w-[16px] h-[16px] flex items-center justify-center leading-none shadow-xs">
              {badge}
            </span>
          )}
        </div>
      </button>
    );
  };

  return (
    <div className="md:hidden fixed bottom-5 left-1/2 -translate-x-1/2 z-40 pointer-events-auto h-[54px] flex items-center justify-between gap-1 sm:gap-1.5 px-2 sm:px-2.5 rounded-full bg-white/85 dark:bg-[#141518]/85 backdrop-blur-md shadow-[0_4px_18px_rgba(0,0,0,0.08)] dark:shadow-[0_4px_22px_rgba(0,0,0,0.4)] transition-all mb-[env(safe-area-inset-bottom)] max-w-[95vw]">
      <NavItem icon="home" label="Home" tab="home" path="/news-hub" />
      <NavItem icon="shield-alert" label="Scams" tab="scams" path="/news-hub" />
      <NavItem icon="plus" label="Report" tab="create" path="/news-hub/create" />
      <NavItem icon="bookmark" label="Saved" tab="saved" path="/news-hub" badge={savedCount} />
      <NavItem icon="user" label="Profile" tab="profile" path="/profile" />
    </div>
  );
};

