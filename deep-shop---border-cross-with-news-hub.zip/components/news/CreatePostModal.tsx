import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Image as ImageIcon, ShieldAlert, Upload, Sparkles, CheckCircle2, AlertTriangle, Phone, DollarSign, UserCheck, Link as LinkIcon } from "lucide-react";
import { auth, db } from "../../firebase";
import { collection, addDoc, doc, getDoc } from "firebase/firestore";
import { useNotify } from "../Notifications";
import { applyWatermarkToImage } from "@/src/lib/watermark";
import { checkNeedsAdminReview } from "@/src/lib/sensitiveReview";
import { uploadToImgbb } from "../../services/imgbb";
import { NewsCategory, NewsPost } from "../../types";
import { useNavigate } from "react-router-dom";

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPostCreated?: (post: NewsPost) => void;
  defaultCategory?: NewsCategory;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  onPostCreated,
  defaultCategory = "Scam Alert",
}) => {
  const notify = useNotify();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<NewsCategory>(defaultCategory);
  const [sourceName, setSourceName] = useState("");

  // Scam Specific details
  const [isScam, setIsScam] = useState(defaultCategory === "Scam Alert" || defaultCategory === "Trending Scam");
  const [scammerName, setScammerName] = useState("");
  const [scammerPhone, setScammerPhone] = useState("");
  const [scammerPaymentInfo, setScammerPaymentInfo] = useState("");
  const [scammedAmount, setScammedAmount] = useState<number | "">("");
  const [scammerSocialLink, setScammerSocialLink] = useState("");

  // Watermarked Image State
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [watermarkedPreview, setWatermarkedPreview] = useState<string>("");
  const [isWatermarking, setIsWatermarking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsWatermarking(true);
    try {
      // Auto-apply "Revealed On DEEP SHOP" fine repeating watermark
      const { dataUrl, file: stampedFile } = await applyWatermarkToImage(file, {
        watermarkText: "Revealed On DEEP SHOP",
        subText: "OFFICIAL SCAM ALERT • VERIFIED REPORT",
        opacity: 0.22,
      });

      setSelectedImageFile(stampedFile);
      setWatermarkedPreview(dataUrl);
      notify("Watermark 'Revealed On DEEP SHOP' applied cleanly to image!", "success");
    } catch (err) {
      console.error("Watermark error:", err);
      notify("Failed to process image watermark", "error");
    } finally {
      setIsWatermarking(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const currentUser = auth.currentUser;
    if (!currentUser) {
      notify("You must be logged in to post. Please sign in or register.", "error");
      navigate("/signin");
      return;
    }

    if (!title.trim()) {
      notify("Please enter a title or headline", "error");
      return;
    }

    if (!content.trim()) {
      notify("Please provide details of the event or scam incident", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      let finalImageUrl = watermarkedPreview;
      if (selectedImageFile) {
        try {
          const uploadedUrl = await uploadToImgbb(selectedImageFile);
          if (uploadedUrl) finalImageUrl = uploadedUrl;
        } catch (uploadErr) {
          console.warn("Upload fallback to watermarked base64", uploadErr);
        }
      }

      // Default placeholder if none provided
      if (!finalImageUrl) {
        finalImageUrl = "https://images.unsplash.com/photo-1588681664899-f142ff2dc9b1?w=800&auto=format&fit=crop&q=80";
      }

      // Check shadow admin review requirement for brand terms
      const needsReview = checkNeedsAdminReview(
        title,
        content,
        scammerName,
        scammerPhone,
        sourceName
      );

      // Get user profile name if possible
      let authorName = currentUser.displayName || currentUser.email?.split("@")[0] || "Deep Shop Citizen";
      let authorAvatar = currentUser.photoURL || "";
      try {
        const uSnap = await getDoc(doc(db, "users", currentUser.uid));
        if (uSnap.exists()) {
          const uData = uSnap.data();
          if (uData.displayName) authorName = uData.displayName;
          if (uData.photoURL) authorAvatar = uData.photoURL;
        }
      } catch (e) {
        // use fallback
      }

      const postPayload: any = {
        title: title.trim(),
        content: content.trim(),
        category: category,
        sourceName: sourceName.trim() || (isScam ? "Community Investigation" : "News Hub Reporter"),
        sourceAvatar: isScam ? "" : "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120",
        isVerifiedSource: !isScam,
        authorId: currentUser.uid,
        authorName: authorName,
        authorEmail: currentUser.email || "",
        authorAvatar: authorAvatar,
        isAuthorVerified: true,
        coverImage: finalImageUrl,
        images: [finalImageUrl],
        watermarked: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        publishedAtStr: new Date().toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        }) + " · " + new Date().toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        }),
        views: 1,
        // Brand terms review rule: if contains "deep shop" etc., status is pending_admin_review
        // otherwise published directly!
        status: needsReview ? "pending_admin_review" : "published",
        sensitiveReviewNeeded: needsReview,

        // Scam details
        isScamReport: isScam || category === "Scam Alert" || category === "Trending Scam",
        scammerName: scammerName.trim() || undefined,
        scammerPhone: scammerPhone.trim() || undefined,
        scammerPaymentInfo: scammerPaymentInfo.trim() || undefined,
        scammedAmount: Number(scammedAmount) || undefined,
        scammerSocialLink: scammerSocialLink.trim() || undefined,
        scamVerdict: "scammer",

        // Initial Voting
        scamVotes: {
          scammerCount: 1,
          suspiciousCount: 0,
          innocentCount: 0,
          userVotes: {
            [currentUser.uid]: "scammer",
          },
        },

        // Initial Reactions
        reactions: {
          like: 1,
          love: 0,
          haha: 0,
          wow: 0,
          sad: 0,
          angry: 0,
          alert: 1,
          userReactions: {
            [currentUser.uid]: "like",
          },
        },
        totalReactions: 1,
        commentsCount: 0,
      };

      const docRef = await addDoc(collection(db, "news_posts"), postPayload);
      const newPostObj: NewsPost = { id: docRef.id, ...postPayload };

      if (onPostCreated) onPostCreated(newPostObj);

      notify("Report published successfully!", "success");
      onClose();
    } catch (err) {
      console.error("Error creating post:", err);
      notify("Failed to create post. Please try again.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col p-6 my-6 text-zinc-900 dark:text-zinc-100"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-150 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-950/50 flex items-center justify-center text-red-600">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                Expose Scam / Post News
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Auto-watermarked with <span className="font-bold text-red-600">Revealed On DEEP SHOP</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {/* Post Category */}
          <div className="flex flex-wrap gap-2">
            {(["Scam Alert", "All News", "Technology", "World", "Sports"] as NewsCategory[]).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  setCategory(cat);
                  setIsScam(cat === "Scam Alert");
                }}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  category === cat
                    ? "bg-black dark:bg-white text-white dark:text-black shadow-sm"
                    : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200"
                }`}
              >
                {cat === "Scam Alert" ? "🚨 Scam Alert / প্রতারক" : cat}
              </button>
            ))}
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
              Headline / Title *
            </label>
            <input
              type="text"
              required
              placeholder={isScam ? "e.g. Scammer stole ৳35,000 posing as phone importer..." : "Headline for article..."}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 text-sm font-semibold outline-none focus:border-red-500"
            />
          </div>

          {/* Scammer Details Box (if scam) */}
          {isScam && (
            <div className="p-4 rounded-2xl bg-red-50/60 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-red-700 dark:text-red-400">
                <AlertTriangle className="w-4 h-4" />
                <span>Fraudster Evidence Data (Will be publicly indexed & searchable)</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                    Scammer Name / Shop Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Shakil Ahmed / Mobile Hub BD"
                    value={scammerName}
                    onChange={(e) => setScammerName(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                    Scammer Contact / Phone Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 017XXXXXXXX"
                    value={scammerPhone}
                    onChange={(e) => setScammerPhone(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none font-mono font-medium"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                    bKash / Nagad / Bank Account
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. bKash Personal 019XXXXXXXX"
                    value={scammerPaymentInfo}
                    onChange={(e) => setScammerPaymentInfo(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                    Amount Scammed (৳)
                  </label>
                  <input
                    type="number"
                    placeholder="৳ 0.00"
                    value={scammedAmount}
                    onChange={(e) => setScammedAmount(e.target.value ? Number(e.target.value) : "")}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none font-bold text-red-600"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Photo Upload with Automatic Watermark */}
          <div>
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
              Evidence Photo / Cover Image (Auto Watermarked)
            </label>
            <div className="flex flex-col sm:flex-row gap-3 items-center">
              <label className="flex-1 w-full flex items-center justify-center gap-2 p-3 rounded-xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 hover:border-red-500 bg-zinc-50 dark:bg-zinc-800/50 cursor-pointer transition">
                <Upload className="w-4 h-4 text-red-600" />
                <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300">
                  {isWatermarking ? "Applying Watermark..." : "Choose Photo (Auto Stamped)"}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </label>

              {watermarkedPreview && (
                <div className="relative w-24 h-20 rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-700 bg-zinc-950 shrink-0">
                  <img
                    src={watermarkedPreview}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <span className="text-[9px] font-bold text-white text-center leading-tight px-1">
                      Revealed On DEEP SHOP
                    </span>
                  </div>
                </div>
              )}
            </div>
            <p className="text-[10px] text-zinc-400 mt-1">
              Any photo uploaded here automatically embeds "Revealed On DEEP SHOP" across the canvas so downloads preserve proof.
            </p>
          </div>

          {/* Content / Narrative */}
          <div>
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
              Full Story & Evidence Details *
            </label>
            <textarea
              required
              rows={4}
              placeholder="Describe what happened, conversation logs, transaction details..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 text-xs font-medium outline-none focus:border-red-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-150 dark:border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs font-bold hover:bg-zinc-100 dark:hover:bg-zinc-800 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || isWatermarking}
              className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-xs font-bold shadow-md transition active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>{isSubmitting ? "Publishing Report..." : "Publish to News Hub"}</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
