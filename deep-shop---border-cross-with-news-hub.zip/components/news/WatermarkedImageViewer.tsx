import React, { useState, useId, useEffect } from "react";
import { Download, ShieldCheck, Maximize2, X, ChevronLeft, ChevronRight } from "lucide-react";
import { downloadWatermarkedImage, applyWatermarkToImage } from "@/src/lib/watermark";

interface WatermarkedImageViewerProps {
  src?: string;
  images?: string[];
  alt?: string;
  className?: string;
  aspectRatio?: string;
  showDots?: boolean;
  allowFullscreen?: boolean;
}

export const WatermarkedImageViewer: React.FC<WatermarkedImageViewerProps> = ({
  src,
  images,
  alt = "Revealed On DEEP SHOP",
  className = "",
  aspectRatio = "aspect-video",
  showDots = true,
  allowFullscreen = true,
}) => {
  const allImages = images && images.length > 0 ? images : src ? [src] : [];
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [bakedDataUrls, setBakedDataUrls] = useState<Record<string, string>>({});
  const patternId = useId();

  const currentImage = allImages[currentIndex] || allImages[0];

  // Auto-bake watermark onto canvas dataUrl so long-press / right-click save ALWAYS downloads watermark
  useEffect(() => {
    if (!currentImage) return;
    if (currentImage.startsWith("data:image/")) return; // already a dataUrl
    if (bakedDataUrls[currentImage]) return;

    let isMounted = true;
    applyWatermarkToImage(currentImage, {
      watermarkText: "Revealed On DEEP SHOP",
      opacity: 0.25,
    })
      .then(({ dataUrl }) => {
        if (isMounted) {
          setBakedDataUrls((prev) => ({ ...prev, [currentImage]: dataUrl }));
        }
      })
      .catch(() => {
        // Fallback: SVG overlay remains visible
      });

    return () => {
      isMounted = false;
    };
  }, [currentImage]);

  if (allImages.length === 0) return null;

  const displaySrc = bakedDataUrls[currentImage] || currentImage;

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await downloadWatermarkedImage(displaySrc, `revealed-on-deep-shop-${Date.now()}.jpg`);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : allImages.length - 1));
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev < allImages.length - 1 ? prev + 1 : 0));
  };

  return (
    <div className={`relative group select-none space-y-2 ${className}`}>
      {/* Main Image Container */}
      <div
        onClick={() => allowFullscreen && setIsFullscreen(true)}
        className={`relative w-full ${aspectRatio} overflow-hidden rounded-2xl bg-zinc-950 flex items-center justify-center cursor-pointer shadow-md border border-zinc-200/60 dark:border-zinc-800`}
      >
        <img
          src={displaySrc}
          alt={alt}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.01]"
        />

        {/* Exactly 4-5 small subtle watermarks with low opacity as requested: "watermark ato gula thakbe na choto choto opacity komano 4-5 ta thakbe" */}
        <div className="absolute inset-0 pointer-events-none select-none z-10 overflow-hidden">
          {[
            { top: "18%", left: "18%" },
            { top: "18%", right: "18%" },
            { top: "50%", left: "50%", transform: "translate(-50%, -50%) rotate(-18deg)" },
            { bottom: "22%", left: "20%" },
            { bottom: "22%", right: "20%" },
          ].map((pos, idx) => (
            <div
              key={idx}
              style={{ ...pos, transform: pos.transform || "rotate(-18deg)" }}
              className="absolute text-[10px] sm:text-xs font-black text-white/25 drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)] tracking-wide whitespace-nowrap uppercase"
            >
              Revealed On DEEP SHOP
            </div>
          ))}
        </div>

        {/* Bottom Verification Badge Strip */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-r from-zinc-950/95 via-zinc-900/90 to-zinc-950/95 border-t border-red-600/70 py-1.5 px-3 flex items-center justify-between text-white z-10 pointer-events-none">
          <div className="flex items-center gap-1.5 text-[10px] font-black tracking-tight text-red-500">
            <ShieldCheck className="w-3.5 h-3.5 text-red-500 shrink-0" />
            <span className="truncate">REVEALED ON DEEP SHOP • VERIFIED</span>
          </div>
          <span className="text-[9px] font-bold text-zinc-300 font-mono shrink-0">
            FRAUD ALERT
          </span>
        </div>

        {/* Floating Top Right Tag */}
        <div className="absolute top-2.5 right-2.5 z-20 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-[9px] font-extrabold text-white border border-white/10 pointer-events-none">
          <ShieldCheck className="w-3 h-3 text-red-500" />
          <span>DEEP SHOP</span>
        </div>

        {/* Multi-Image Navigation Controls */}
        {allImages.length > 1 && (
          <>
            <button
              type="button"
              onClick={handlePrev}
              className="absolute left-2 top-1/2 -translate-y-1/2 z-20 w-7 h-7 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              className="absolute right-2 top-1/2 -translate-y-1/2 z-20 w-7 h-7 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <div className="absolute top-2.5 left-2.5 z-20 px-2 py-0.5 rounded-full bg-black/60 text-white text-[10px] font-mono font-bold">
              {currentIndex + 1} / {allImages.length}
            </div>
          </>
        )}

        {/* Hover Toolbar */}
        <div className="absolute inset-0 z-20 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-2.5 pointer-events-none">
          <span className="text-[10px] font-bold text-white drop-shadow-sm flex items-center gap-1">
            Watermarked Evidence
          </span>
          <div className="flex items-center gap-1.5 pointer-events-auto">
            {allowFullscreen && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFullscreen(true);
                }}
                className="p-1 rounded-lg bg-white/20 hover:bg-white/30 backdrop-blur-md text-white transition cursor-pointer"
                title="Full screen view"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white text-[11px] font-bold shadow-md transition active:scale-95 cursor-pointer"
              title="Download Watermarked Image"
            >
              <Download className="w-3 h-3" />
              <span>Download</span>
            </button>
          </div>
        </div>
      </div>

      {/* Horizontal Scrollable Thumbnails for multiple images ("abr image gula scroll kore dekha jabe") */}
      {allImages.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {allImages.map((imgUrl, idx) => (
            <button
              key={idx}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setCurrentIndex(idx);
              }}
              className={`relative shrink-0 w-16 h-12 rounded-xl overflow-hidden border-2 transition cursor-pointer ${
                idx === currentIndex
                  ? "border-red-600 ring-2 ring-red-500/30 scale-105"
                  : "border-transparent opacity-60 hover:opacity-100"
              }`}
            >
              <img
                src={bakedDataUrls[imgUrl] || imgUrl}
                alt=""
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      )}

      {/* Fullscreen Lightbox Modal ("full screen aa oo dekha jabe") */}
      {isFullscreen && (
        <div
          className="fixed inset-0 z-[99999] bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-3 select-none"
          onClick={() => setIsFullscreen(false)}
        >
          <div className="absolute top-4 right-4 z-50 flex items-center gap-2">
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Watermarked</span>
            </button>
            <button
              onClick={() => setIsFullscreen(false)}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div
            className="relative max-w-5xl max-h-[85vh] w-full flex items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative overflow-hidden rounded-2xl max-h-[80vh] flex items-center justify-center">
              <img
                src={displaySrc}
                alt={alt}
                className="max-w-full max-h-[80vh] object-contain rounded-2xl shadow-2xl"
              />
              {/* 5 Discrete subtle watermarks with low opacity in fullscreen lightbox */}
              <div className="absolute inset-0 pointer-events-none select-none z-10 overflow-hidden">
                {[
                  { top: "20%", left: "20%" },
                  { top: "20%", right: "20%" },
                  { top: "50%", left: "50%", transform: "translate(-50%, -50%) rotate(-18deg)" },
                  { bottom: "24%", left: "22%" },
                  { bottom: "24%", right: "22%" },
                ].map((pos, idx) => (
                  <div
                    key={idx}
                    style={{ ...pos, transform: pos.transform || "rotate(-18deg)" }}
                    className="absolute text-xs sm:text-sm font-black text-white/25 drop-shadow-[0_1px_3px_rgba(0,0,0,0.85)] tracking-wide whitespace-nowrap uppercase"
                  >
                    Revealed On DEEP SHOP
                  </div>
                ))}
              </div>
            </div>

            {allImages.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={handlePrev}
                  className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center backdrop-blur-md transition cursor-pointer"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  type="button"
                  onClick={handleNext}
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center backdrop-blur-md transition cursor-pointer"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
