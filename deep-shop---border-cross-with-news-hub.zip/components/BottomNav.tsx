import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { Home, ShoppingBag, Heart, MessageCircle, User } from "lucide-react";
import { triggerHaptic } from "../lib/haptics";

const BottomNav: React.FC = () => {
  const location = useLocation();
  const [cartCount, setCartCount] = React.useState(0);

  React.useEffect(() => {
    const updateCount = () => {
      try {
        const cartStr = localStorage.getItem('f_cart');
        let cart = [];
        try { cart = cartStr && cartStr !== "undefined" ? JSON.parse(cartStr) : []; } catch(e){}
        if (Array.isArray(cart)) {
          const validItems = cart.filter(item => item && (item.id || item.productId));
          const count = validItems.reduce((acc: number, item: any) => acc + (item.quantity || 1), 0);
          setCartCount(count);
        } else {
          setCartCount(0);
        }
      } catch (e) {
        setCartCount(0);
      }
    };
    updateCount();
    window.addEventListener("update_cart", updateCount);
    return () => window.removeEventListener("update_cart", updateCount);
  }, []);

  // 1. Never show shopping BottomNav on News Hub or news details pages ("shopping site ar kicui thakbe na")
  // 2. Also hide on product detail, checkout, admin, messages pages
  if (
    location.pathname.startsWith("/news-hub") ||
    location.pathname.startsWith("/product/") ||
    location.pathname.startsWith("/checkout") ||
    location.pathname.startsWith("/messages") ||
    location.pathname.startsWith("/seller") ||
    location.pathname.startsWith("/admin")
  ) {
    return null;
  }

  // Exact 5 wireframe dock icons: Home, Cart/Bag, Heart, Message, User
  const navItems = [
    { to: "/", icon: Home, label: "Home" },
    { to: "/cart", icon: ShoppingBag, label: "Cart", badge: cartCount },
    { to: "/wishlist", icon: Heart, label: "Wishlist" },
    { to: "/aichat", icon: MessageCircle, label: "Chat" },
    { to: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-3 inset-x-4 max-w-sm mx-auto z-[100] md:hidden">
      {/* Floating Dark Pill Dock matching the wireframe design */}
      <div className="rounded-full bg-zinc-950/95 dark:bg-zinc-900/95 backdrop-blur-xl border border-white/15 shadow-[0_10px_30px_rgba(0,0,0,0.45)] px-2.5 py-1.5 flex items-center justify-between">
        {navItems.map((item) => {
          const isActive = item.to === "/" 
            ? location.pathname === "/" 
            : location.pathname.startsWith(item.to);
          const IconComponent = item.icon;

          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => triggerHaptic()}
              className="relative flex items-center justify-center p-1"
            >
              {/* When active: white pill / circle matching wireframe dock icon */}
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isActive
                    ? "bg-white text-zinc-950 shadow-md scale-105"
                    : "text-zinc-400 hover:text-white"
                }`}
              >
                <IconComponent
                  className={`w-5 h-5 transition-transform ${
                    isActive ? "stroke-[2.5]" : "stroke-[1.8]"
                  }`}
                />
              </div>

              {/* Cart Counter Badge */}
              {item.badge !== undefined && item.badge > 0 && (
                <span className="absolute 1 top-0 right-0 bg-red-600 text-white text-[9px] font-black w-4 h-4 flex items-center justify-center rounded-full border-2 border-zinc-950 shadow-sm animate-scale-in">
                  {item.badge}
                </span>
              )}
            </NavLink>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav;
