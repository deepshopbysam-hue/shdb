import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  ShieldAlert, PlusCircle, ArrowRight, Flame 
} from "lucide-react";
import { collection, query, orderBy, limit, onSnapshot } from "firebase/firestore";
import { db } from "../../firebase";
import { NewsPost } from "../../types";

export const HomeVigilanceSection: React.FC = () => {
  const navigate = useNavigate();
  const [recentReports, setRecentReports] = useState<NewsPost[]>([]);

  useEffect(() => {
    const q = query(
      collection(db, "news_posts"),
      orderBy("createdAt", "desc"),
      limit(3)
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const fetched = snap.docs.map((d) => ({ id: d.id, ...d.data() } as NewsPost));
        if (fetched.length > 0) {
          setRecentReports(fetched);
        } else {
          setRecentReports([
            {
              id: "scam_demo_home",
              title: "🚨 SCAM ALERT: Fake Seller 'Gadget Point' reported for ৳15,000 bKash fraud",
              content: "User ordered a border cross phone with 50% advance through bKash 01799887766. After payment, the number was blocked immediately.",
              category: "Scam Alert",
              tags: ["#scamalert", "#fraud"],
              authorId: "deep_vigilance",
              authorName: "Deep Shop Vigilance",
              isAuthorVerified: true,
              createdAt: Date.now() - 3600 * 1000,
              publishedAtStr: "1h ago",
              views: 142,
              status: "published",
              isScamReport: true,
              scammerName: "Rakibul Islam (Gadget Point)",
              scammerPhone: "01799887766",
              scammedAmount: 15000,
              totalReactions: 14,
              commentsCount: 5,
            }
          ]);
        }
      },
      () => {
        setRecentReports([]);
      }
    );
    return () => unsub();
  }, []);

  return (
    <div className="mb-8 w-full animate-fade-in group px-0">
      <div className="relative overflow-hidden rounded-[22px] bg-gradient-to-br from-[#120726] via-[#1a0f35] to-[#0d071a] border border-red-500/30 p-4 sm:p-5 text-white shadow-xl">
        {/* Subtle decorative glow */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-36 h-36 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Block: Strictly Single-Line everywhere */}
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div className="min-w-0 flex-1 space-y-1">
            {/* Badge & Sub-tag in single line */}
            <div className="flex items-center gap-2 overflow-hidden whitespace-nowrap">
              <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 text-[9px] font-black uppercase tracking-wider flex items-center gap-1 whitespace-nowrap shrink-0">
                <Flame className="w-3 h-3 text-red-400" />
                <span>PUBLIC VIGILANCE HUB</span>
              </span>
              <span className="text-[10px] sm:text-[11px] text-zinc-400 font-medium whitespace-nowrap truncate">
                অনলাইন স্ক্যাম সচেতনতা প্ল্যাটফর্ম
              </span>
            </div>

            {/* Title: Single Line */}
            <h2 className="text-sm sm:text-base font-black tracking-tight text-white whitespace-nowrap truncate">
              স্ক্যাম বা প্রতারণার শিকার হয়েছেন? প্রকাশ্যে রিপোর্ট করুন
            </h2>

            {/* Description: Single Line */}
            <p className="text-[10px] sm:text-[11px] text-zinc-300 whitespace-nowrap truncate max-w-full">
              অনলাইন কেনাকাটায় ভুয়া পেইজ, ফেক অ্যাডভান্স ও বিকাশ প্রতারকদের নম্বর ও প্রমাণাদি প্রকাশ্যে রিপোর্ট করুন।
            </p>
          </div>

          {/* Action Buttons: Single Line */}
          <div className="flex items-center gap-2 shrink-0 overflow-x-auto no-scrollbar pt-1 md:pt-0">
            <button
              type="button"
              onClick={() => navigate("/news-hub/create")}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] shadow-md shadow-red-600/30 active:scale-95 transition cursor-pointer whitespace-nowrap shrink-0 leading-none"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="whitespace-nowrap">রিপোর্ট করুন (Report)</span>
            </button>
            <button
              type="button"
              onClick={() => navigate("/news-hub")}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold text-[11px] border border-white/15 active:scale-95 transition cursor-pointer whitespace-nowrap shrink-0 leading-none"
            >
              <span className="whitespace-nowrap">ভিজিল্যান্স হাব</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Recent Scam Reports Mini-Feed: Single-Line Cards */}
        {recentReports.length > 0 && (
          <div className="relative z-10 pt-3 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-zinc-400">
              <span className="font-bold flex items-center gap-1.5 text-zinc-300 whitespace-nowrap truncate">
                <ShieldAlert className="w-3.5 h-3.5 text-red-400 shrink-0" />
                <span className="whitespace-nowrap truncate">সাম্প্রতিক উন্মোচিত অভিযোগ ও রিপোর্ট</span>
              </span>
              <button
                type="button"
                onClick={() => navigate("/news-hub")}
                className="hover:text-white transition flex items-center gap-1 text-[10px] whitespace-nowrap shrink-0 ml-2"
              >
                <span className="whitespace-nowrap">সবগুলো</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              {recentReports.map((report) => (
                <div
                  key={report.id}
                  onClick={() => navigate(`/news-hub/${report.id}`)}
                  className="bg-white/5 hover:bg-white/10 border border-white/10 hover:border-red-500/40 rounded-xl p-2.5 transition-all cursor-pointer flex flex-col justify-between group/card overflow-hidden"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center justify-between text-[9px] gap-1">
                      <span className="px-1.5 py-0.5 rounded-full bg-red-500/20 text-red-300 font-bold border border-red-500/30 whitespace-nowrap shrink-0">
                        {report.category || "Scam Alert"}
                      </span>
                      <span className="text-zinc-400 font-mono whitespace-nowrap shrink-0">
                        {report.publishedAtStr || "Recent"}
                      </span>
                    </div>

                    <h4 className="text-[11px] sm:text-xs font-bold text-white whitespace-nowrap truncate group-hover/card:text-red-400 transition-colors">
                      {report.title}
                    </h4>

                    {report.scammerPhone && (
                      <div className="text-[10px] text-zinc-300 flex items-center gap-1 whitespace-nowrap truncate">
                        <span className="text-zinc-400">নম্বর:</span>
                        <span className="font-mono font-bold text-red-400 whitespace-nowrap truncate">{report.scammerPhone}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1.5 mt-1 border-t border-white/5 text-[10px] text-zinc-400">
                    <span className="whitespace-nowrap">{report.totalReactions || 0} টি সমর্থন</span>
                    <span className="text-red-400 font-semibold group-hover/card:translate-x-1 transition-transform flex items-center gap-0.5 whitespace-nowrap shrink-0">
                      <span className="whitespace-nowrap">বিস্তারিত</span>
                      <ArrowRight className="w-2.5 h-2.5" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
